﻿#include "nonUniformArray.h"
#include "queue.h"
#include<vector>
#include<algorithm>
#include<cmath>

double verbose = false; // 调试值
bool testPrint = false;
bool Algshort = false;
const int L = 10000, W = 1000, h = 300; // 调试场景
const int numUsers = 3000; // 调试场景
const int numClusters = 40; // 调试场景
double R = 600, r = 450; // 调试场景
const int numUAVs = 30; // 调试场景 
const int delta = 300; // 300 meters
const int numHoverLocations = (L / delta) * (W / delta) + numClusters + 4*(4+3+2+1); // 调试场景
/*
const int L = 3000, W = 3000, h = 300; 
const int numUsers = 3000; 
const int numClusters = 40;
double R = 600, r = 500;
const int numUAVs = 5;*/
int numUsersPerCluster[numClusters];
double xCluster[numClusters], yCluster[numClusters];
bool isCovered[numClusters];
bool isExtraCovered[numClusters];

//assert(h < r);
double userCommRadius = sqrt(r*r - h*h); // the user communication radius at altitude h
int CapUAV = 100; // the maximum number of users that a UAV can serve

//const int numHoverLocations = (L / delta) * (W / delta) + numClusters + 4*(3+2+1);
double xHoverLoc[numHoverLocations], yHoverLoc[numHoverLocations]; // the candidate hovering locations at altitude h
int minHops[numHoverLocations][numHoverLocations];
bool adjMatrix[numHoverLocations][numHoverLocations];

bool isLocCoverUserMatrix[numHoverLocations][numClusters];
int locCoverSpecCluster[numHoverLocations][numClusters];
double disMatrix[numClusters][numHoverLocations];

bool isToDeployUAV[numHoverLocations];
int nearestEdgeWeight[numHoverLocations];

int hoverLocations[numHoverLocations];
int bestHoverLocations[numHoverLocations];
int numLocCoverClusters[numHoverLocations];
int numDeployedLocations;
int D;

double Pt = -6; // transmission power of UAV (dB)
double gt = 5; // gain of UAV (dB)
double PN = -105; // noise power (dB)
double pl_cons = 40.4; // = 20 log_10 (4pi f_c /c), dB
double pl_fadingLOS = 1; // fading loss of los link
double pl_fadingNLOS = 20; // fading loss of NLOS link
double Bw = 2.5; // MHz

double avgDataRates[numClusters][numHoverLocations];

int residualUsers[numClusters], residualUAVCap[numHoverLocations];
struct Edge {
	int userID;
	int locationID;
	double dataRate;
};
Edge allEdges[numClusters * numUAVs];// throughput calculation
Edge preAllEdges[numHoverLocations][numClusters]; // initial calculation
Edge allDeployedEdges[numClusters * numUAVs]; // realtime calculation
Edge testNodeEdges[numClusters * numUAVs]; // realtime calculation
Edge assignedTestEdges[numClusters * numHoverLocations];// realtime assignment
int numInitialSumEdges[numHoverLocations]; // initial calculation
inline bool cmp(Edge & x, Edge& y) { return x.dataRate > y.dataRate; }

double distance2D(double x1, double y1, double x2, double y2)
{
	double dx = x1 - x2, dy = y1 - y2;
	return sqrt(dx*dx + dy * dy);
}

double distance3D(double x1, double y1, double z1, double x2, double y2, double z2)
{
	double dx = x1 - x2, dy = y1 - y2, dz = z1 - z2;
	return sqrt(dx * dx + dy * dy + dz * dz);
}

inline double Uniform()
{
	//return (rand() % Mode) / (double)Mode;
	return double(rand()) / RAND_MAX;
}

inline int calSegH()
{
    int segH;
    
    if ((userCommRadius <= R / 2) && (userCommRadius > 0)) 
    {
        segH = 2;
    }
    else if ((userCommRadius <= sqrt(2) * R / 2) && (userCommRadius > R / 2)) 
    {
        segH = 3;
    }
    else if ((userCommRadius <= R) && (userCommRadius > sqrt(2) * R / 2)) 
    {
        segH = 4;
    }
    else 
    {
        return 0;
    }
    return segH;
}

class maxUAVCoverage{
public:
	void initialization();
public:
	double AlgKnapsack();
	double AlgKnapsackSlow();
	double AlgTreeDecomp();
	double AlgAssign();
	double ApproAlgShort();
	double ApproAlgLong();

	double profitEachLocation[numHoverLocations];
	double AlgTreeDecomp_old();
	double AlgGreedy();
protected:
	void findShortestPath(int s);
	void findAllShortestPath();
	int extendByGreedy();
	int extendByGreedyModified(); // 调试
	void extendByGreedyProfitLabel();
protected:
	bool visited[1000];
	int parentSPT[1 + numClusters + numHoverLocations + 1];
	// int disFromSource[numHoverLocations];
	int allParentSPT[1 + numClusters + numHoverLocations + 1][1 + numClusters + numHoverLocations + 1];
	// int allDisFromSource[numHoverLocations][numHoverLocations];
public:
	void calAvgDataRates();
	int calMaxUsers();
	double calMaxThroughput();
	void preCalEdges();
	int calDeployedCoverUsers();
	// int calExtraCoverUsers(); // 临时增加的节点所额外覆盖的用户
	void calUsersCoveredPerLocation();
protected:
	void assignUserLocations();
	void assignHoverLocatoins();
	void findMinHopsAmongLocations();
/*public:
	nonUniformArray<flowGraphEdge> flowGraph;
	nonUniformArray<residualGraphEdge> residualGraph;*/
};

void maxUAVCoverage::preCalEdges()
{
	int cluster, location;
	//int locationID;
	Edge oneEdge;
	int numEdges;
	// pre calculating all the edges
	for (location = 0; location < numHoverLocations; location++)
	{
		oneEdge.locationID = location;
		numInitialSumEdges[location] = 0;
		numEdges = 0;
		for (cluster = 0; cluster < numClusters; cluster++)
		{
			if (disMatrix[cluster][location] > userCommRadius) continue;
			oneEdge.userID = cluster;
			oneEdge.dataRate = avgDataRates[cluster][location];
			//oneEdge.isLabelled = false;
			preAllEdges[location][numEdges] = oneEdge;
			numEdges++;
		}
		numInitialSumEdges[location] = numEdges;
		if (testPrint)
		{
			printf("the initial number of edges on location %d\t is %d\n", location, numEdges);
		}
		
	}
}

double maxUAVCoverage::calMaxThroughput()
{
	//assert(numDeployedLocations <= numUAVs);
	int i, j;
	int locationID;
	Edge oneEdge;
	int numEdges = 0;
	//all edges
	for (i = 0; i < numClusters; ++i)
	{
		oneEdge.userID = i;
		for (j = 0; j < numDeployedLocations; ++j)
		{
			locationID = hoverLocations[j];
			//printf("the deployed location is %d\n", locationID);
			//assert(locationID >= 0 && locationID < numHoverLocations);
			if (disMatrix[i][locationID] > userCommRadius) continue;
			oneEdge.locationID = locationID;
			oneEdge.dataRate = avgDataRates[i][locationID];
			allEdges[numEdges] = oneEdge;
			numEdges++;
		}
	}
	if (0 == numEdges) return 0;
	sort(allEdges, allEdges+numEdges, cmp); // sort in decreasing order

	for (i = 0; i < numClusters; ++i)
		residualUsers[i] = numUsersPerCluster[i];
	for (j = 0; j < numHoverLocations; ++j)
		residualUAVCap[j] = CapUAV;

	int userID;
	int k;
	int minCap;
	double sumDataRates = 0;
	for (k = 0; k < numEdges; ++k)
	{
		userID = allEdges[k].userID;
		locationID = allEdges[k].locationID;
		minCap = residualUsers[userID];
		if (residualUAVCap[locationID] < minCap)
			minCap = residualUAVCap[locationID];
		sumDataRates += minCap * allEdges[k].dataRate;

		residualUsers[userID] -= minCap;
		residualUAVCap[locationID] -= minCap;
	}
	return sumDataRates;
}

int maxUAVCoverage::calMaxUsers()
{
	//assert(numDeployedLocations <= numUAVs);
	int i, j;
	int locationID;
	Edge oneEdge;
	int numEdges = 0;
	//all edges
	for (i = 0; i < numClusters; ++i)
	{
		oneEdge.userID = i;
		for (j = 0; j < numDeployedLocations; ++j)
		{
			locationID = hoverLocations[j];
			//assert(locationID >= 0 && locationID < numHoverLocations);
			if (disMatrix[i][locationID] > r) continue;
			oneEdge.locationID = locationID;
			oneEdge.dataRate = avgDataRates[i][locationID];
			allEdges[numEdges] = oneEdge;
			numEdges++;
		}
	}
	if (0 == numEdges) return 0;
	sort(allEdges, allEdges+numEdges, cmp); // sort in decreasing order

	for (i = 0; i < numClusters; ++i)
		residualUsers[i] = numUsersPerCluster[i]; // 每群剩余未覆盖用户数量
	for (j = 0; j < numDeployedLocations; ++j)
		residualUAVCap[hoverLocations[j]] = CapUAV; // 每个无人机位置剩余承载量

	int userID;
	int k;
	int minCap;
	// double sumDataRates = 0;
	int sumCoveredUsers = 0;
	for (k = 0; k < numEdges; ++k)
	{
		// 对于某条边
		userID = allEdges[k].userID; // 连接的用户群ID
		locationID = allEdges[k].locationID; // 连接的位置ID
		minCap = residualUsers[userID]; // 该用户群的人数
		if (residualUAVCap[locationID] < minCap) // 该位置剩余量 小于 该用户群人数
			minCap = residualUAVCap[locationID]; 
		// sumDataRates += minCap * allEdges[k].dataRate; // 该位置剩余量 大于 该用户群人数，直接计算
		sumCoveredUsers += minCap;

		residualUsers[userID] -= minCap; // 该用户群剩余未覆盖人数
		residualUAVCap[locationID] -= minCap; // 无人机剩余承载量
	}
	return sumCoveredUsers;
}

void maxUAVCoverage::calAvgDataRates()
{
	int i, j;
	double eucliDistance;
	double horizonalDistance;
	double pl_dis;
	double pl_los, pl_nlos;
	double SNR_los, SNR_nlos;
	double data_los, data_nlos;
	double angle;
	double a = 9.611725, b = 0.158062;
	double e = 2.71828;
	double prob_LOS;
	double dataRate;
	for(i=0; i<numClusters; ++i)
		for (j = 0; j < numHoverLocations; ++j)
		{
			horizonalDistance = distance2D( xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j]);
			eucliDistance = sqrt(horizonalDistance* horizonalDistance + double(h) * h);
			if (eucliDistance > r) {	avgDataRates[i][j] = 0;		continue; }

			pl_dis = 20.0 * log10(eucliDistance);

			pl_los =  pl_cons  + pl_dis +  pl_fadingLOS;
			SNR_los = pow(10.0, (Pt + gt - pl_los - PN)/10.0);
			data_los = Bw * log2(1.0 + SNR_los);

			pl_nlos = pl_cons + pl_dis + pl_fadingNLOS;
			SNR_nlos = pow(10.0, (Pt + gt - pl_nlos - PN) / 10.0);
			data_nlos = Bw * log2(1.0 + SNR_nlos);

			angle = 180.0 * asin(h / eucliDistance)/3.1415926; // elevation angle, in degree
			prob_LOS = 1.0 / (1.0 + a * pow(e, -b*(angle-a)));

			dataRate = prob_LOS * data_los + (1.0 - prob_LOS) * data_nlos;
			avgDataRates[i][j] = dataRate;
			// if(testPrint) printf("user: (%.0lf, %.0lf), uav:(%.0lf, %.0lf), dis: %.0lf, dataLoS: %.3lf, dataNLoS: %.3lf, angle: %.2lf, probLOS: %.3lf, avgDataRate: %.2lf Mbps\n ", xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j], eucliDistance, data_los, data_nlos, angle, prob_LOS, dataRate);
			if(testPrint) printf("user: %d\t, location: %d\t, avgDataRate: %.2lf Mbps\n ", i, j, dataRate);
		}
}

double maxUAVCoverage::AlgKnapsack()
{
	int i, j, k, l, m, z;
	double maxThroughput = 0;
	int loop_time = 0;

	int u, v;

	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];
	int residualUsersCopy[numClusters];

	int clusterID;
	int locationID;
	int testClusterID = 0;
	int testLocationID = 0;
	int testMinCap = 0;
	int updateClusterID = 0;
	int updateLocationID = 0;
	int updateMinCap = 0;
	int updateLocation = 0;

	int numTestEdges;
	int numDeployedEdges;

	int numMaxDeployedLocations = 0;
	int maxDeployedLocations[numHoverLocations];
	int numUpdate = 0;

	double totalThroughput;

	// initial one node
	for (i = 0; i < numHoverLocations; ++i)
	{
		numDeployedLocations = 1;
		hoverLocations[0] = i;
		for (k = 0; k < numHoverLocations; ++k)	isToDeployUAV[k] = false;
		isToDeployUAV[i] = true;
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------	
		int minDis;
		int nearestNode;
		// Find the shortest distances and paths to the nodes already in the subtree
		for (k = 0; k < numHoverLocations; ++k) 
		{
			// printf("isToDeployUAV is %d\n", isToDeployUAV[halfDHops[test1]]); // 调试
			if (true == isToDeployUAV[k]) continue;
			
			MinDistances[k] = minHops[i][k];
			allNearestNodes[k] = i;
		}

		// initial totoal throughput
		int deployedLocation = 0;
		int minCap = 0;
		totalThroughput = 0;
		numDeployedEdges = 0;

		// directly calculating
		// totalThroughput = calMaxThroughput();
		// printf("the initial node is %d and the total throughput now is %.2lf\n", i, totalThroughput);
		
		//******do not need to calculate initial throughput
		//******but need to initialing the residuals
		// initialinig residuals
		for (k = 0; k < numClusters; k++)
			residualUsers[k] = numUsersPerCluster[k];
		for (k = 0; k < numHoverLocations; k++)
			residualUAVCap[k] = CapUAV;
		// choosing edges of deployed locations and sorting
		for (k = 0; k < numDeployedLocations; k++)
		{
			deployedLocation = hoverLocations[k];
			for (l = 0; l < numInitialSumEdges[deployedLocation]; l++)
			{
				allDeployedEdges[numDeployedEdges] = preAllEdges[deployedLocation][l];
				// when we need to calculate all edges in the extension testing process
				// we need to first initial the testnodeedges array
				// testNodeEdges[numDeployedEdges] = preAllEdges[deployedLocation][l];
				numDeployedEdges++;
			}
		}//******do not need to calculate initial throughput
		//******but need to initialing the residuals
		
		// calculating initial throughput
		/*sort(allDeployedEdges, allDeployedEdges+numDeployedEdges, cmp);
		for (k = 0; k < numDeployedEdges; k++)
		{
			clusterID = allDeployedEdges[k].userID;
			locationID = allDeployedEdges[k].locationID;
			minCap = residualUsers[clusterID];
			if (residualUAVCap[locationID] < minCap)
				minCap = residualUAVCap[locationID];
			totalThroughput += minCap * allDeployedEdges[k].dataRate;
			
			residualUsers[clusterID] -= minCap;
			residualUAVCap[locationID] -= minCap;
		}*/
		// printf("the initial node is %d and the total throughput now is %.2lf\n", i, totalThroughput);
		
		int bestNextLocation;
		double bestIncreasedThroughput;
		double curTestThroughput = 0;
		double bestRatio;
		int nextNode = 0;
		int testNode = 0;
		int numTestLocations = 0;
		int testDeployedLocation = 0;
		while (numDeployedLocations < numUAVs)
		{
			// multi hops node
			bestRatio = -1;
			// neighbor node
			// bestIncreasedThroughput = -1;
			for (testNode = 0; testNode < numHoverLocations; ++testNode)
			{
				if (true == isToDeployUAV[testNode]) continue;
				// if (MinDistances[testNode] >= 2) continue;  // do not see the nodes that are far away
					
				// version of : the node can be far away
				if (numDeployedLocations + MinDistances[testNode] > numUAVs) continue;
				// dierectly calculating all the nodes on the shortest path
				
				// start : adding the nodes on the shortest path, and
				// choosing all edges of these nodes
				numTestLocations = numDeployedLocations; // saving the number before testing
				// printf("the number of deployed locations is %d\n", numTestLocations);
				hoverLocations[numDeployedLocations] = testNode;
				numDeployedLocations++;
				nearestNode = allNearestNodes[testNode];
				v = testNode;
				while (nearestNode != allParentSPT[nearestNode][v])
				{
					nextNode = allParentSPT[nearestNode][v];
					hoverLocations[numDeployedLocations] = nextNode;
					++numDeployedLocations;
					v = nextNode;
				}
				numTestEdges = 0; // segment-1
				curTestThroughput = 0;
				// choosing edges
				for (k = numTestLocations; k < numDeployedLocations; k++)
				{
					testDeployedLocation = hoverLocations[k];
					for (l = 0; l < numInitialSumEdges[testDeployedLocation]; l++)
					{
						testNodeEdges[numTestEdges] = preAllEdges[testDeployedLocation][l];
						numTestEdges++;
					}
				}
				// printf("the number of edges of location %d is %d\n", testNode, numTestEdges);
				sort(testNodeEdges, testNodeEdges + numTestEdges, cmp);
				for (k = 0; k < numTestEdges; k++)
				{
					testClusterID = testNodeEdges[k].userID;
					testLocationID = testNodeEdges[k].locationID; // when not only one node
					testMinCap = residualUsers[testClusterID];
					if (residualUAVCap[testLocationID] < testMinCap)
						testMinCap = residualUAVCap[testLocationID];
					curTestThroughput += testMinCap * testNodeEdges[k].dataRate;
					// residualUsers[testClusterID] -= testMinCap;
					residualUAVCap[testLocationID] -= testMinCap;
				}
				// comparing with the best: two versions
				// version 1-1 : if far away node + minhops -----> good one
				if(1.0 * (curTestThroughput) / (double)minHops[i][testNode] > bestRatio)
				{
					bestRatio = 1.0 * (curTestThroughput) / (double)minHops[i][testNode];
					bestNextLocation = testNode;
				}
				numDeployedLocations = numTestLocations;
				// version 1-2 : if far away node + minDistances
				/*if(1.0 * (curTestThroughput) / (double)MinDistances[testNode] > bestRatio)
				{
					bestRatio = 1.0 * (curTestThroughput) / (double)MinDistances[testNode];
					// bestIncreasedThroughput = curTestThroughput - totalThroughput;
					bestNextLocation = testNode;
				}
				numDeployedLocations = numTestLocations;*/

				/*curTestThroughput = 0;
				curTestThroughput = calMaxThroughput();
				if (curTestThroughput - totalThroughput > bestIncreasedThroughput)
				{
					bestIncreasedThroughput = curTestThroughput - totalThroughput;
					// bestRatio = 1.0 * (curTestThroughput - totalThroughput) / (double)MinDistances[testNode];
					bestNextLocation = testNode;
				}
				--numDeployedLocations;*/

				// printf("the number of deployed locations is %d\n", numDeployedLocations);
				// curTestThroughput = calMaxThroughput();
				// printf("the current throughput is %.2lf\n", curTestThroughput);
				// numDeployedLocations = numTestLocations;
				// printf("the number of deployed locations is %d\n", numDeployedLocations);
				/*if (1.0 * (curTestThroughput - totalThroughput) / (double)minHops[i][testNode] > bestRatio)
				{
					bestRatio = 1.0 * (curTestThroughput - totalThroughput) / (double)minHops[i][testNode];
					bestNextLocation = testNode;
				}*/
				
				// only calculating the data rate of testnode
				/* start : neighbor + calculating test node increment*/
				/*numTestEdges = 0; // segment-1
				curTestThroughput = 0;
				for (k = 0; k < numInitialSumEdges[testNode]; k++)
				{
					testNodeEdges[k] = preAllEdges[testNode][k];
					numTestEdges++;
				}
				// printf("the number of edges of location %d is %d\n", testNode, numTestEdges);
				sort(testNodeEdges, testNodeEdges + numTestEdges, cmp);
				for (k = 0; k < numTestEdges; k++)
				{
					testClusterID = testNodeEdges[k].userID;
					testMinCap = residualUsers[testClusterID];
					if (residualUAVCap[testNode] < testMinCap)
						testMinCap = residualUAVCap[testNode];
					curTestThroughput += testMinCap * testNodeEdges[k].dataRate;
					// residualUsers[testClusterID] -= testMinCap;
					residualUAVCap[testNode] -= testMinCap;
				}*/ // segment-1
				// end : neighbor + calculating test node increment
				// printf("the throughput added by node %d is %.2lf\n", testNode, curTestThroughput);
				
				// comparing with the best: two versions
				// version 1-1 : if far away node + minhops -----> good one
				/*if(1.0 * (curTestThroughput) / (double)minHops[i][testNode] > bestRatio)
				{
					bestRatio = 1.0 * (curTestThroughput) / (double)minHops[i][testNode];
					// bestIncreasedThroughput = curTestThroughput - totalThroughput;
					bestNextLocation = testNode;
				}*/
				// version 1-2 : if far away node + minDistances
				/*if(1.0 * (curTestThroughput) / (double)MinDistances[testNode] > bestRatio)
				{
					bestRatio = 1.0 * (curTestThroughput) / (double)MinDistances[testNode];
					// bestIncreasedThroughput = curTestThroughput - totalThroughput;
					bestNextLocation = testNode;
				}*/

				// version 2 : neighbor
				/*if (curTestThroughput > bestIncreasedThroughput) // segment-2
				{
					bestIncreasedThroughput = curTestThroughput;
					bestNextLocation = testNode;
				}*/ // segment-2
				
				/* start : neighbor + calculating total increment*/
				/*hoverLocations[numDeployedLocations] = testNode;
				numDeployedLocations++;
				curTestThroughput = calMaxThroughput();
				--numDeployedLocations;
				if (curTestThroughput - totalThroughput > bestIncreasedThroughput)
				{
					bestIncreasedThroughput = curTestThroughput - totalThroughput;
					bestNextLocation = testNode;
				}*/
			}
			if (bestRatio == 0) break;
			// if (bestIncreasedThroughput == 0) break;
			
			// added the nodes on the shortest path
			
			// neighbor + calculating testnode version
			/*hoverLocations[numDeployedLocations] = bestNextLocation;
			numDeployedLocations++;
			isToDeployUAV[bestNextLocation] = true;
			totalThroughput = calMaxThroughput();*/

			// neighbor +calculating all edges version
			/*hoverLocations[numDeployedLocations] = bestNextLocation;
			numDeployedLocations++;
			isToDeployUAV[bestNextLocation] = true;
			totalThroughput += bestIncreasedThroughput;*/
			
			// edges version
			// numUpdate = numDeployedLocations;
			
			// far away node
			hoverLocations[numDeployedLocations] = bestNextLocation;
			numDeployedLocations++;
			isToDeployUAV[bestNextLocation] = true;
			nearestNode = allNearestNodes[bestNextLocation];
			v = bestNextLocation;
			while (nearestNode != allParentSPT[nearestNode][v])
			{
				nextNode = allParentSPT[nearestNode][v];
				hoverLocations[numDeployedLocations] = nextNode;
				isToDeployUAV[nextNode] = true;
				++numDeployedLocations;
				v = nextNode;
			}
			// directly adding
			// totalThroughput += bestRatio * (double)minHops[i][bestNextLocation];
			totalThroughput = calMaxThroughput();
			
			// choosing the edges on the shortest path
			
			// choosing edges for far away node
			/*for (k = numUpdate; k < numDeployedLocations; k++) // replacing initial k value : numupdate or 0
			{
				updateLocation = hoverLocations[k];
				for (l = 0; l < numInitialSumEdges[updateLocation]; l++)
				{
					allDeployedEdges[numDeployedEdges] = preAllEdges[updateLocation][l];
					numDeployedEdges++;
				}
			}*/

			// choosing edges for neighbor
			/*for (k = 0; k < numInitialSumEdges[bestNextLocation]; k++)
			{
				allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLocation][k];
				numDeployedEdges++;
			}
			sort(allDeployedEdges, allDeployedEdges+numDeployedEdges, cmp);
			// calculating the total throughput of all edges
			totalThroughput = 0;
			for (k = 0; k < numClusters; k++)
				residualUsers[k] = numUsersPerCluster[k];
			for (k = 0; k < numHoverLocations; k++)
				residualUAVCap[k] = CapUAV;
			for (k = 0; k < numDeployedEdges; k++)
			{
				updateClusterID = allDeployedEdges[k].userID;
				updateLocationID = allDeployedEdges[k].locationID;
				updateMinCap = residualUsers[updateClusterID];
				if (residualUAVCap[updateLocationID] < updateMinCap)
					updateMinCap = residualUAVCap[updateLocationID];
				totalThroughput += updateMinCap * allDeployedEdges[k].dataRate;

				residualUsers[updateClusterID] -= updateMinCap;
				residualUAVCap[updateLocationID] -= updateMinCap;
			}*/
			// printf("the best location is %d and now the total throughput is %.2lf\n", bestNextLocation, totalThroughput);
			
			//update the shortest paths and distances
			for (l = 0; l < numHoverLocations; ++l)
			{
				if (true == isToDeployUAV[l]) continue;
				for (k = numDeployedLocations - MinDistances[bestNextLocation]; k < numDeployedLocations; ++k)
				{
					v = hoverLocations[k];
					if (minHops[l][v] < MinDistances[l])
					{
						MinDistances[l] = minHops[l][v];
						allNearestNodes[l] = v;
					}
				}
			}
		}
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------	
		if (maxThroughput < totalThroughput)
		{
			maxThroughput = totalThroughput;
			/*numMaxDeployedLocations = numDeployedLocations;
			for (k = 0; k < numMaxDeployedLocations; k++)
				maxDeployedLocations[k] = hoverLocations[k];*/
		}
	}
	/*numDeployedLocations = numMaxDeployedLocations;
	for (k = 0; k < numDeployedLocations; k++)
	{
		hoverLocations[k] = maxDeployedLocations[k];
		printf("the location is %d\n", hoverLocations[k]);
	}
	maxThroughput = calMaxThroughput();*/
	return maxThroughput;
}

double maxUAVCoverage::AlgKnapsackSlow()
{
	int i, j, k, l, m, z;
	int loop_time = 0;

	int u, v;
	int clusterID;

	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];

	int residualUsersCopy[numClusters];

	int numDeployedEdges;
	double totalThroughput;
	double maxThroughput = 0;
	double curTestThroughput;
	double bestIncreasedThroughput;

	int testClusterID = 0;
	int testLocationID = 0;
	int testMinCap = 0;
	int numTestEdges = 0;

	// initial two nodes
	for (i = 0; i < numHoverLocations; ++i) 
	{
		for (j = i+1; j < numHoverLocations; ++j)
		{	
			if (minHops[i][j] > numUAVs - 1) continue;
			for (k = 0; k < numHoverLocations; ++k)	isToDeployUAV[k] = false;

			numDeployedLocations = 1;
			hoverLocations[0] = j;
			isToDeployUAV[j] = true;

			v = j;
			while (-1 != allParentSPT[i][v])
			{
				u = allParentSPT[i][v];
				hoverLocations[numDeployedLocations] = u;
				++numDeployedLocations;
				isToDeployUAV[u] = true;
				v = u;
			}				
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------					
			int minDis;
			int nearestNode;
			// Find the shortest distances and paths to the nodes already in the subtree
			for (k = 0; k < numHoverLocations; ++k)
			{
				// printf("isToDeployUAV is %d\n", isToDeployUAV[halfDHops[test1]]); // 调试
				if (true == isToDeployUAV[k]) continue;
				minDis = 1000000;
				for (l = 0; l < numDeployedLocations; ++l)
				{
					v = hoverLocations[l];
					if (minHops[k][v] < minDis)
					{
						minDis = minHops[k][v];
						nearestNode = v;
					}
				}
				MinDistances[k] = minDis;
				allNearestNodes[k] = nearestNode;
			}

			// initial totoal throughput
			int deployedLocation = 0;
			int minCap = 0;
			totalThroughput = 0;
			numDeployedEdges = 0;

			// directly calculating
			// totalThroughput = calMaxThroughput();
			// printf("the initial node is %d and the total throughput now is %.2lf\n", i, totalThroughput);
		
			//******do not need to calculate initial throughput
			//******but need to initialing the residuals
			// initialinig residuals
			for (k = 0; k < numClusters; k++)
				residualUsers[k] = numUsersPerCluster[k];
			for (k = 0; k < numHoverLocations; k++)
				residualUAVCap[k] = CapUAV;
			// choosing edges of deployed locations and sorting
			for (k = 0; k < numDeployedLocations; k++)
			{
				deployedLocation = hoverLocations[k];
				for (l = 0; l < numInitialSumEdges[deployedLocation]; l++)
				{
					allDeployedEdges[numDeployedEdges] = preAllEdges[deployedLocation][l];
					// when we need to calculate all edges in the extension testing process
					// we need to first initial the testnodeedges array
					// testNodeEdges[numDeployedEdges] = preAllEdges[deployedLocation][l];
					numDeployedEdges++;
				}
			}//******do not need to calculate initial throughput
			//******but need to initialing the residuals
		
			// calculating initial throughput
			/*sort(allDeployedEdges, allDeployedEdges+numDeployedEdges, cmp);
			for (k = 0; k < numDeployedEdges; k++)
			{
				clusterID = allDeployedEdges[k].userID;
				locationID = allDeployedEdges[k].locationID;
				minCap = residualUsers[clusterID];
				if (residualUAVCap[locationID] < minCap)
					minCap = residualUAVCap[locationID];
				totalThroughput += minCap * allDeployedEdges[k].dataRate;
			
				residualUsers[clusterID] -= minCap;
				residualUAVCap[locationID] -= minCap;
			}*/
			// printf("the initial node is %d and the total throughput now is %.2lf\n", i, totalThroughput);
				
			int bestNextLocation;
			double bestRatio;
			int curMinCap; 
			int nextNode;
			int testNode;
			int numTestLocations = 0;
			int testDeployedLocation = 0;
		    while (numDeployedLocations < numUAVs)
			{
				//bestRatio = -1;
				bestIncreasedThroughput = -1;
				for (testNode = 0; testNode < numHoverLocations; ++testNode)
				{
					if (true == isToDeployUAV[testNode]) continue;
					if (MinDistances[testNode] >= 2) continue;  // do not see the nodes that are far away
					// if (numDeployedLocations + MinDistances[testNode] > numUAVs ) continue;
					
					// only calculating the data rate of testnode
					/* start : neighbor + calculating test node increment*/
					numTestEdges = 0; // segment-1
					curTestThroughput = 0;
					for (k = 0; k < numInitialSumEdges[testNode]; k++)
					{
						testNodeEdges[k] = preAllEdges[testNode][k];
						numTestEdges++;
					}
					// printf("the number of edges of location %d is %d\n", testNode, numTestEdges);
					sort(testNodeEdges, testNodeEdges + numTestEdges, cmp);
					for (k = 0; k < numTestEdges; k++)
					{
						testClusterID = testNodeEdges[k].userID;
						testMinCap = residualUsers[testClusterID];
						if (residualUAVCap[testNode] < testMinCap)
							testMinCap = residualUAVCap[testNode];
						curTestThroughput += testMinCap * testNodeEdges[k].dataRate;
						// residualUsers[testClusterID] -= testMinCap;
						residualUAVCap[testNode] -= testMinCap;
					} // segment-1
					if (curTestThroughput > bestIncreasedThroughput) // segment-2
					{
						bestIncreasedThroughput = curTestThroughput;
						bestNextLocation = testNode;
					} // segment-2

					// start : adding the nodes on the shortest path, and
					// choosing all edges of these nodes
					/*numTestLocations = numDeployedLocations; // saving the number before testing
					// printf("the number of deployed locations is %d\n", numTestLocations);
					hoverLocations[numDeployedLocations] = testNode;
					numDeployedLocations++;
					nearestNode = allNearestNodes[testNode];
					v = testNode;
					while (nearestNode != allParentSPT[nearestNode][v])
					{
						nextNode = allParentSPT[nearestNode][v];
						hoverLocations[numDeployedLocations] = nextNode;
						++numDeployedLocations;
						v = nextNode;
					}
					numTestEdges = 0; // segment-1
					curTestThroughput = 0;
					// choosing edges
					for (k = numTestLocations; k < numDeployedLocations; k++)
					{
						testDeployedLocation = hoverLocations[k];
						for (l = 0; l < numInitialSumEdges[testDeployedLocation]; l++)
						{
							testNodeEdges[numTestEdges] = preAllEdges[testDeployedLocation][l];
							numTestEdges++;
						}
					}
					// printf("the number of edges of location %d is %d\n", testNode, numTestEdges);
					sort(testNodeEdges, testNodeEdges + numTestEdges, cmp);
					for (k = 0; k < numTestEdges; k++)
					{
						testClusterID = testNodeEdges[k].userID;
						testLocationID = testNodeEdges[k].locationID; // when not only one node
						testMinCap = residualUsers[testClusterID];
						if (residualUAVCap[testLocationID] < testMinCap)
							testMinCap = residualUAVCap[testLocationID];
						curTestThroughput += testMinCap * testNodeEdges[k].dataRate;
						// residualUsers[testClusterID] -= testMinCap;
						residualUAVCap[testLocationID] -= testMinCap;
					}*/
					// comparing with the best: two versions
					// version 1-1 : if far away node + minhops
					/*if(1.0 * (curTestThroughput) / (double)(minHops[i][testNode] + minHops[j][testNode]) > bestRatio)
					{
						bestRatio = 1.0 * (curTestThroughput) / (double)(minHops[i][testNode] + minHops[j][testNode]);
						bestNextLocation = testNode;
					}*/

					// version 1-2 : far away node + mindistances
					/*if(1.0 * (curTestThroughput) / (double)MinDistances[testNode] > bestRatio)
					{
						bestRatio = 1.0 * (curTestThroughput) / (double)MinDistances[testNode];
						bestNextLocation = testNode;
					}*/

					// version 2 : far away node + total throughput
					/*if (curTestThroughput > bestIncreasedThroughput)
					{
						bestIncreasedThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}*/
					
					//numDeployedLocations = numTestLocations;
				}
				if (bestIncreasedThroughput == 0) break;
				//if (bestRatio == 0) break;
			
				// added the nodes on the shortest path
			
				// neighbor + calculating testnode version
				hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;
				totalThroughput = calMaxThroughput();

				// far away node
				/*hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;
				nearestNode = allNearestNodes[bestNextLocation];
				v = bestNextLocation;
				while (nearestNode != allParentSPT[nearestNode][v])
				{
					nextNode = allParentSPT[nearestNode][v];
					hoverLocations[numDeployedLocations] = nextNode;
					isToDeployUAV[nextNode] = true;
					++numDeployedLocations;
					v = nextNode;
				}
				totalThroughput = calMaxThroughput();*/

				//update the shortest paths and distances
				for (l = 0; l < numHoverLocations; ++l)
				{
					if (true == isToDeployUAV[l]) continue;
					for (k = numDeployedLocations - MinDistances[bestNextLocation]; k < numDeployedLocations; ++k)
					{
						v = hoverLocations[k];

						if (minHops[l][v] < MinDistances[l])
						{
							MinDistances[l] = minHops[l][v];
							allNearestNodes[l] = v;
						}
					}
				}
			}
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy分割线----------------------------------------------------------------------------------------	
			if (maxThroughput < totalThroughput)
				maxThroughput = totalThroughput;			
		}
	}
	return maxThroughput;
}

double maxUAVCoverage::ApproAlgLong()
{
	int i, j, k, l, m;
	double maxThroughput = 0;
	// double curThroughput;
	int loop_time = 0;

	int minHopsA = 0, minHopsB = 0, minHopsC = 0, minSum = 0;
	int s1 = 0, t1 = 0, s2 = 0, t2 = 0;
	int u, v;
	//int clusterID;
	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];

	int bestHoveringLocations[numHoverLocations];
	int bestNumHoveringLocations;

	bool isLabelled[numHoverLocations];
	for (i = 0; i < numHoverLocations; ++i) isLabelled[i] = false;
	for (i = 0; i < numHoverLocations; ++i) profitEachLocation[i] = 0;

	//int curIncreasedThroughput;
	double bestAssignedThroughput;
	double curAssignedThroughput;
	double sumThroughput = 0;
	int bestNextLoc;
	//int restUAVCap;
	//int lessCap;

	int assignClusterID;
	int assignLocationID;
	int assignMinCap;
	int updateClusterID = 0;
	int updateLocationID = 0;
	int updateMinCap;
	int numDeployedEdges = 0;
	int numTestEdges;

	int assignResidualUsers[numClusters];
	int assignResidualUAVCap[numHoverLocations];

	numDeployedLocations = 0;
	for (k = 0; k < numClusters; k++)
		residualUsers[k] = numUsersPerCluster[k];
	for (k = 0; k < numHoverLocations; k++)
		residualUAVCap[k] = CapUAV;
	
	// assign profit for each hovering location
	// finding maximum profit each loop by decreasing order
	for (i = 0; i < numHoverLocations; ++i)// number of locations
	{
		bestAssignedThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j) // each location
		{
			if (true == isLabelled[j]) continue;
			curAssignedThroughput = 0;
			numTestEdges = 0;

			// only calculating the throughput of the location j
			for (k = 0; k < numInitialSumEdges[j]; k++)
			{	
				assignedTestEdges[k] = preAllEdges[j][k];
				numTestEdges++;
			}
			// printf("the number of edges of location %d is %d\n", j, numTestEdges);
			sort(assignedTestEdges, assignedTestEdges + numTestEdges, cmp);
			for (k = 0; k < numTestEdges; k++)
			{
				assignClusterID = assignedTestEdges[k].userID;
				// assignLocationID = assignedTestEdges[k].locationID;
				assignMinCap = residualUsers[assignClusterID];
				if (residualUAVCap[j] < assignMinCap)
					assignMinCap = residualUAVCap[j];
				curAssignedThroughput += assignMinCap * assignedTestEdges[k].dataRate;
				// residualUsers[assignClusterID] -= assignMinCap;
				residualUAVCap[j] -= assignMinCap;
			}
			// printf("the throughput of location %d is %.2lf\n", j, curAssignedThroughput);

			if(curAssignedThroughput > bestAssignedThroughput)
			{
				bestAssignedThroughput = curAssignedThroughput;
				bestNextLoc = j;
			}
		}

		// assign profit for the best location
		isLabelled[bestNextLoc] = true;
		bestAssignedThroughput = 0; // reseting for resuing the variable
		// adding the edges of the best location into allDeployedEdges array
		for (k = 0; k < numInitialSumEdges[bestNextLoc]; k++)
		{
			allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLoc][k];
			numDeployedEdges++;
		}
		sort(allDeployedEdges, allDeployedEdges + numDeployedEdges, cmp);
		// residual arrays need to be reset whenever we need to calculate the throughput of all edges
		for (k = 0; k < numHoverLocations; k++)
			residualUAVCap[k] = CapUAV;
		for (k = 0; k < numClusters; k++)
			residualUsers[k] = numUsersPerCluster[k];
		// calculating the throughput of all edges
		for (k = 0; k < numDeployedEdges; k++)
		{
			updateClusterID = allDeployedEdges[k].userID;
			updateLocationID = allDeployedEdges[k].locationID;
			updateMinCap = residualUsers[updateClusterID];
			if (residualUAVCap[updateLocationID] < updateMinCap)
				updateMinCap = residualUAVCap[updateLocationID];
			bestAssignedThroughput += updateMinCap * allDeployedEdges[k].dataRate;

			residualUsers[updateClusterID] -= updateMinCap;
			residualUAVCap[updateLocationID] -= updateMinCap;
		}

		profitEachLocation[bestNextLoc] = bestAssignedThroughput - sumThroughput;
		// printf("the sum throghput now is %.2lf, the best throughput now is %.2lf, the best location is %d and its profit is %.2lf\n", sumThroughput, bestAssignedThroughput, bestNextLoc, profitEachLocation[bestNextLoc]);
		sumThroughput = bestAssignedThroughput;
		
		if (bestAssignedThroughput == 0) break;
		//printf("%d th node, assign profit to node %d, profit: %d\n", i + 1, bestNextLoc, bestIncreaseFlow);
	}

	// initial three nodes
	for (i = 0; i < numHoverLocations; ++i)
	{
		for (j = i + 1; j < numHoverLocations; ++j)
		{
			for (k = j + 1; k < numHoverLocations; ++k)
			{
				// loop_time++;
				minHopsA = minHops[i][j] + minHops[i][k];
				minHopsB = minHops[i][j] + minHops[j][k];
				minHopsC = minHops[j][k] + minHops[i][k];
				// keep t1 = t2
				if (minHopsA <= minHopsB) {
					minSum = minHopsA;
					s1 = j;
					t1 = i;
					s2 = k;
					t2 = i;
				}
				else {
					minSum = minHopsB;
					s1 = i;
					t1 = j;
					s2 = k;
					t2 = j;
				}
				if (minSum > minHopsC) {
					minSum = minHopsC;
					s1 = j;
					t1 = k;
					s2 = i;
					t2 = k;
				}
				if (minSum > numUAVs - 1) continue;

				for (l = 0; l < numHoverLocations; ++l)	isToDeployUAV[l] = false;

				numDeployedLocations = 1;
				hoverLocations[0] = s2;
				isToDeployUAV[s2] = true;
				v = s2;
				while (-1 != allParentSPT[t2][v])
				{
					u = allParentSPT[t2][v];
					hoverLocations[numDeployedLocations] = u;
					++numDeployedLocations;
					isToDeployUAV[u] = true;
					v = u;
				}
				hoverLocations[numDeployedLocations] = s1;
				numDeployedLocations++;
				isToDeployUAV[s1] = true;
				v = s1;
				while (t1 != allParentSPT[t1][v])
				{
					u = allParentSPT[t1][v]; // t1 = t2
					if (false == isToDeployUAV[u])
					{
						hoverLocations[numDeployedLocations] = u;
						++numDeployedLocations;
						isToDeployUAV[u] = true;
					}
					v = u;
				}
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
				int minDis;
				int nearestNode;
				// Find the shortest distances and paths to the nodes already in the subtree
				for (m = 0; m < numHoverLocations; ++m)
				{
					// printf("isToDeployUAV is %d\n", isToDeployUAV[halfDHops[test1]]); // 调试
					if (true == isToDeployUAV[m]) continue;
					minDis = 1000000;
					for (l = 0; l < numDeployedLocations; ++l)
					{
						v = hoverLocations[l];
						if (minHops[m][v] < minDis)
						{
							minDis = minHops[m][v];
							nearestNode = v;
						}	
					}
					MinDistances[m] = minDis;
					allNearestNodes[m] = nearestNode;
				}

				// initial total
				double totalThroughput = 0;
				for (l = 0; l < numDeployedLocations; ++l)
					totalThroughput += profitEachLocation[hoverLocations[l]];
				//printf("initial total is %2lf\n", totalThroughput);

				int bestNextLocation;
				double bestIncreaseThroughput;
				double curTestThroughput;
				int testNode;
				int nextNode = 0;
				double bestRatio;
				while (numDeployedLocations < numUAVs)
				{
					// bestIncreaseThroughput = -1;
					bestRatio = -1;
					for (testNode = 0; testNode < numHoverLocations; ++testNode)
					{
						if (true == isToDeployUAV[testNode]) continue;
						/*if (MinDistances[testNode] >= 2) continue;  // do not see the nodes that are far away

						curTestThroughput = profitEachLocation[testNode];
						if (curTestThroughput > bestIncreaseThroughput)
						{
							bestIncreaseThroughput = curTestThroughput;
							bestNextLocation = testNode;
						}
						// no better hovering locations, now is the best
						//if (bestIncreasedUsers == residualUAVCap[testNode]) break;
						if (bestIncreaseThroughput == -1) break;*/


						// version : far away node
						if (numDeployedLocations + MinDistances[testNode] > numUAVs) continue;
						hoverLocations[numDeployedLocations] = testNode;
						numDeployedLocations++;
						nearestNode = allNearestNodes[testNode];
						v = testNode;
						curTestThroughput = profitEachLocation[testNode];
						while (nearestNode != allParentSPT[nearestNode][v]) // not the root of the tree
						{
							nextNode = allParentSPT[nearestNode][v];
							hoverLocations[numDeployedLocations] = nextNode;
							++numDeployedLocations;
							v = nextNode;
							curTestThroughput += profitEachLocation[nextNode];
						}

						if (1.0 * curTestThroughput / (double)MinDistances[testNode] > bestRatio)
						{
							bestRatio = 1.0 * curTestThroughput / (double)MinDistances[testNode];
							bestIncreaseThroughput = curTestThroughput;
							bestNextLocation = testNode;
						}
						/*if (curTestThroughput > bestIncreaseThroughput)
						{
							bestIncreaseThroughput = curTestThroughput;
							bestNextLocation = testNode;
						}*/
						numDeployedLocations -= MinDistances[testNode];
					}

					// added the nodes on the shortest path
					hoverLocations[numDeployedLocations] = bestNextLocation;
					numDeployedLocations++;
					isToDeployUAV[bestNextLocation] = true;

					nearestNode = allNearestNodes[bestNextLocation];
					v = bestNextLocation;
					// curTestUsers = profitEachLocation[bestNextLocation];
					while (nearestNode != allParentSPT[nearestNode][v])
					{
						nextNode = allParentSPT[nearestNode][v];
						hoverLocations[numDeployedLocations] = nextNode;
						isToDeployUAV[nextNode] = true;
						++numDeployedLocations;
						v = nextNode;
					}

					totalThroughput += bestIncreaseThroughput;

					//update the shortest paths and distances				
					for (l = 0; l < numHoverLocations; ++l)
					{
						if (true == isToDeployUAV[l]) continue;
						for (m = numDeployedLocations - MinDistances[bestNextLocation]; m < numDeployedLocations; ++m)
						{
							v = hoverLocations[m];
							if (minHops[l][v] < MinDistances[l])
							{
								MinDistances[l] = minHops[l][v];
								allNearestNodes[l] = v;
							}
						}
					}
				}
				// finish
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
				if (maxThroughput < totalThroughput)
				{
					maxThroughput = totalThroughput;
					bestNumHoveringLocations = numDeployedLocations;
					for (l = 0; l < numDeployedLocations; ++l)
						bestHoveringLocations[l] = hoverLocations[l];
				}
				// if (loop_time % 50000 == 0) printf("loop time: %d, time: %.2lf seconds\n", loop_time, (clock() - st) / 1000.0);
			}
		}
	}
	numDeployedLocations = bestNumHoveringLocations;
	for (l = 0; l < numDeployedLocations; ++l) // 保存用最优解的目的是：利用最优解计算最大吞吐，而不是用最优解对应的profiteachlocation之和当作最大吞吐
	{	
		hoverLocations[l] = bestHoveringLocations[l];
		// printf("the location is %d\n", hoverLocations[l]);
	}
	maxThroughput = calMaxThroughput();
	return maxThroughput;
}

double maxUAVCoverage::AlgGreedy()
{
	int i, j, k, l;
	double maxThroughput = 0;
	// double curThroughput;
	int loop_time = 0;

	int u, v;
	int clusterID;

	int bestHoveringLocations[numHoverLocations];
	int bestNumHoveringLocations;

	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];

	bool isLabelled[numHoverLocations];
	for (i = 0; i < numHoverLocations; ++i) isLabelled[i] = false;
	for (i = 0; i < numHoverLocations; ++i) profitEachLocation[i] = 0;

	double curAssignedThroughput;
	double sumAssignedThroughput = 0;
	double bestAssignedThroughput;
	int bestNextLoc;
	int restUAVCap;
	int lessCap;

	int numAssTestEdges;
	int bestClusterID;
	int bestLocationID;
	int bestMinCap;
	int numDeployedEdges = 0;

	int assignedClusterID = 0;
	int assignedLocationID = 0;
	int assignedMinCap = 0;


	// assign profit for each hovering location
	numDeployedLocations = 0;
	for (i = 0; i < numHoverLocations; ++i)
	{
		bestAssignedThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isLabelled[j]) continue;
			hoverLocations[numDeployedLocations] = j;
			numDeployedLocations++;
			curAssignedThroughput = calMaxThroughput();
			--numDeployedLocations;
			if(curAssignedThroughput - sumAssignedThroughput > bestAssignedThroughput)
			{
				bestAssignedThroughput = curAssignedThroughput - sumAssignedThroughput;
				bestNextLoc = j;
			}

			// choosing edges of the assign test node
			/*numAssTestEdges = 0;
			curAssignedThroughput = 0;
			for (l = 0; l < numInitialSumEdges[j]; l++)
			{
				assignedTestEdges[l] = preAllEdges[j][l];
				numAssTestEdges++;
			}
			// printf("the number of edges of location %d is %d\n", j, numAssTestEdges);
			sort(assignedTestEdges, assignedTestEdges+numAssTestEdges, cmp);
			for (l = 0; l < numAssTestEdges; l++) // edges of test node 
			{
				assignedClusterID = assignedTestEdges[l].userID;
				// assignedLocationID = assignedTestEdges[l].locationID;
				assignedMinCap = residualUsers[assignedClusterID];
				if(residualUAVCap[j] < assignedMinCap)
					assignedMinCap = residualUAVCap[j];
				curAssignedThroughput += assignedMinCap * assignedTestEdges[l].dataRate;
				residualUAVCap[j] -= assignedMinCap;
				// residualUsers[assignedClusterID] -= assignedMinCap;
			}
			// printf("the throughput of location %d is %.2lf\n", j, curAssignedThroughput);
			if (curAssignedThroughput > bestAssignedThroughput)
			{
				bestAssignedThroughput = curAssignedThroughput;
				bestNextLoc = j;
			}*/
		}
		// directly calculate total throughput
		isLabelled[bestNextLoc] = true;
		profitEachLocation[bestNextLoc] = bestAssignedThroughput;
		sumAssignedThroughput += bestAssignedThroughput;
		hoverLocations[numDeployedLocations] = bestNextLoc;
		++numDeployedLocations;

		/*isLabelled[bestNextLoc] = true;
		bestAssignedThroughput = 0;

		// calculate the test node 
		// reseting the residual arrays as we need to calculate all edges
		for (l = 0; l < numClusters; l++)
			residualUsers[l] = numUsersPerCluster[l];
		for (l = 0; l < numHoverLocations; l++)
			residualUAVCap[l] = CapUAV;
		// adding the new edges into all deployed array
		for (l = 0; l < numInitialSumEdges[bestNextLoc]; l++)
		{
			allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLoc][l];
			numDeployedEdges++;
		}
		// calculating the total throughput
		sort(allDeployedEdges, allDeployedEdges + numDeployedEdges, cmp);
		for (l = 0; l < numDeployedEdges; l++)
		{
			bestClusterID = allDeployedEdges[l].userID;
			bestLocationID = allDeployedEdges[l].locationID;
			bestMinCap = residualUsers[bestClusterID];
			if (residualUAVCap[bestLocationID] < bestMinCap)
				bestMinCap = residualUAVCap[bestLocationID];
			// the total throughput after adding the best location
			bestAssignedThroughput += bestMinCap * allDeployedEdges[l].dataRate;
				
			residualUAVCap[bestLocationID] -= bestMinCap;
			residualUsers[bestClusterID] -= bestMinCap;
		}
		profitEachLocation[bestNextLoc] = bestAssignedThroughput - sumAssignedThroughput;
		// printf("the sum throughput now is %.2lf, the best throughput now is %.2lf, the best location is %d and its profit is %.2lf\n", sumAssignedThroughput, bestAssignedThroughput, bestNextLoc, profitEachLocation[bestNextLoc]);
		sumAssignedThroughput = bestAssignedThroughput;*/
		if (bestAssignedThroughput == 0) break;
		//printf("%d th node, assign profit to node %d, profit: %d\n", i + 1, bestNextLoc, bestIncreaseFlow);
	}// the operation of assigning profit finishes
	
	// initial two nodes
	for (i = 0; i < numHoverLocations; ++i)
	{
		for (j = i + 1; j < numHoverLocations; ++j)
		{
			if (minHops[i][j] > numUAVs - 1) continue;
			for (k = 0; k < numHoverLocations; ++k)	isToDeployUAV[k] = false;

			numDeployedLocations = 1;
			hoverLocations[0] = j;
			isToDeployUAV[j] = true;

			v = j;
			while (-1 != allParentSPT[i][v])
			{
				u = allParentSPT[i][v];
				hoverLocations[numDeployedLocations] = u;
				++numDeployedLocations;
				isToDeployUAV[u] = true;
				v = u;
			}
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
			int minDis;
			int nearestNode;
			// Find the shortest distances and paths to the nodes already in the subtree
			for (k = 0; k < numHoverLocations; ++k)
			{
				// printf("isToDeployUAV is %d\n", isToDeployUAV[halfDHops[test1]]); // 调试
				if (true == isToDeployUAV[k]) continue;
				minDis = 1000000;
				for (l = 0; l < numDeployedLocations; ++l)
				{
					v = hoverLocations[l];
					if (minHops[k][v] < minDis)
					{
						minDis = minHops[k][v];
						nearestNode = v;
					}
				}
				MinDistances[k] = minDis;
				allNearestNodes[k] = nearestNode;
			}

			double totalThroughput = 0;
			for (l = 0; l < numDeployedLocations; ++l)
				totalThroughput += profitEachLocation[ hoverLocations[l] ];
			// printf("initial total is %d\n", totalUsers);

			int bestNextLocation;
			// int bestIncreasedUsers;
			double bestTestThroughput;
			double curTestThroughput = 0;
			double bestRatio;
			// int curTestUsers;
			int nextNode;
			int testNode;
			while (numDeployedLocations < numUAVs)
			{
				// bestRatio = -1;
				bestTestThroughput = -1;
				for (testNode = 0; testNode < numHoverLocations; ++testNode)
				{
					if (true == isToDeployUAV[testNode]) continue;
					
					// neighbor version
					if (MinDistances[testNode] >= 2) continue;  // do not see the nodes that are far away
					hoverLocations[numDeployedLocations] = testNode;
					numDeployedLocations++;
					curTestThroughput = profitEachLocation[testNode];
					if (curTestThroughput > bestTestThroughput)
					{
						bestTestThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}
					--numDeployedLocations;

					// far away node version
					/*if (numDeployedLocations + MinDistances[testNode] > numUAVs) continue;
					hoverLocations[numDeployedLocations] = testNode;
					numDeployedLocations++;
					nearestNode = allNearestNodes[testNode];
					v = testNode;
					curTestThroughput = profitEachLocation[testNode];
					while (nearestNode != allParentSPT[nearestNode][v]) // not the root of the tree
					{
						nextNode = allParentSPT[nearestNode][v];
						hoverLocations[numDeployedLocations] = nextNode;
						++numDeployedLocations;
						v = nextNode;
						curTestThroughput += profitEachLocation[nextNode];
					}

					if (1.0 * curTestThroughput / (double)MinDistances[testNode] > bestRatio)
					{
						bestRatio = 1.0 * curTestThroughput / (double)MinDistances[testNode];
						bestTestThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}
					numDeployedLocations -= MinDistances[testNode];*/
				}
				//printf("bestIncreasedUsers is %d and bestNextLocation is %d\n", bestIncreasedUsers, bestNextLocation); 

				// added the nodes on the shortest path
				
				// version : neighbor
				hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;
				totalThroughput += bestTestThroughput;
				
				// version :far away node
				/*hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;
				nearestNode = allNearestNodes[bestNextLocation];
				v = bestNextLocation;
				// curTestThroughput = profitEachLocation[bestNextLocation];
				while (nearestNode != allParentSPT[nearestNode][v])
				{
					nextNode = allParentSPT[nearestNode][v];
					hoverLocations[numDeployedLocations] = nextNode;
					isToDeployUAV[nextNode] = true;
					++numDeployedLocations;
					v = nextNode;
					//curTestThroughput += profitEachLocation[nextNode];
				}
				// totalThroughput += bestRatio * (double)MinDistances[bestNextLocation];
				totalThroughput += bestTestThroughput;*/


				//update the shortest paths and distances
				for (l = 0; l < numHoverLocations; ++l)
				{
					if (true == isToDeployUAV[l]) continue;
					for (k = numDeployedLocations - MinDistances[bestNextLocation]; k < numDeployedLocations; ++k)
					{
						v = hoverLocations[k];

						if (minHops[l][v] < MinDistances[l])
						{
							MinDistances[l] = minHops[l][v];
							allNearestNodes[l] = v;
						}
					}
				}
			}
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
			if (maxThroughput < totalThroughput)
			{
				maxThroughput = totalThroughput;
				bestNumHoveringLocations = numDeployedLocations;
				for (l = 0; l < numDeployedLocations; ++l)
					bestHoveringLocations[l] = hoverLocations[l];
			}	
		}
	}
	numDeployedLocations = bestNumHoveringLocations;
	for (i = 0; i < numDeployedLocations; ++i)
		hoverLocations[i] = bestHoveringLocations[i];
	maxThroughput = calMaxThroughput();
	return maxThroughput;
}

double maxUAVCoverage::AlgAssign()
{
	int i, j, k, l;
	double maxThroughput = 0;
	int loop_time = 0;

	int u, v;
	int clusterID;

	int bestHoveringLocations[numHoverLocations];
	int bestNumHoveringLocations;

	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];

	bool isLabelled[numHoverLocations];
	double curAssignedThroughput;
	double bestAssignedThroughput;
	double sumAssignedThroughput;
	double bestAssignedRatio;
	int bestNextLoc;

	int assignedTestNode;
	int numDeployedEdges;
	int assignedClusterID = 0;
	int assignedLocationID = 0;
	int assignedMinCap = 0;
	int assignedResidualUsers[numClusters];
	int assignedResidualUAVCap[numHoverLocations];
	int numAssTestEdges;

	int bestClusterID = 0;
	int bestLocationID = 0;
	int bestMinCap = 0;

	for (int firstNode = 0; firstNode < numHoverLocations; ++firstNode) // times
	{
		//initial residual arrays
		for (i = 0; i < numHoverLocations; ++i) 
		{
			isLabelled[i] = false;
			profitEachLocation[i] = 0;
			residualUAVCap[i] = CapUAV;
		}
		for (i = 0; i < numClusters; i++)
			residualUsers[i] = numUsersPerCluster[i];
		
		sumAssignedThroughput = 0;
		numDeployedEdges = 0;

		// assign profit for each hovering location
		for (i = 0; i < numHoverLocations; ++i)
		{
			bestAssignedThroughput = -1;
			// bestAssignedRatio = -1;
			if (i == 0) bestNextLoc = firstNode;
			else
			{
				for (j = 0; j < numHoverLocations; ++j)
				{
					if (true == isLabelled[j]) continue;

					// choosing edges of the assign test node
					numAssTestEdges = 0;
					curAssignedThroughput = 0;
					for (l = 0; l < numInitialSumEdges[j]; l++)
					{
						assignedTestEdges[l] = preAllEdges[j][l];
						numAssTestEdges++;
					}
					// printf("the number of edges of location %d is %d\n", j, numAssTestEdges);
					sort(assignedTestEdges, assignedTestEdges+numAssTestEdges, cmp);
					for (l = 0; l < numAssTestEdges; l++) // edges of test node 
					{
						assignedClusterID = assignedTestEdges[l].userID;
						// assignedLocationID = assignedTestEdges[l].locationID;
						assignedMinCap = residualUsers[assignedClusterID];
						if(residualUAVCap[j] < assignedMinCap)
							assignedMinCap = residualUAVCap[j];
						curAssignedThroughput += assignedMinCap * assignedTestEdges[l].dataRate;
						residualUAVCap[j] -= assignedMinCap;
						// residualUsers[assignedClusterID] -= assignedMinCap;
					}
					// printf("the throughput of location %d is %.2lf\n", j, curAssignedThroughput);
					if (curAssignedThroughput > bestAssignedThroughput)
					{
						bestAssignedThroughput = curAssignedThroughput;
						bestNextLoc = j;
					}

					/*if (1.0 * curAssignedThroughput / (double)numAssTestEdges > bestAssignedRatio)
					{
						bestAssignedRatio = 1.0 * curAssignedThroughput / (double)numAssTestEdges;
						bestNextLoc = j;
					}*/
					
				}
			}
			// assign profit for the best location
			isLabelled[bestNextLoc] = true;
			bestAssignedThroughput = 0;
			
			// reseting the residual arrays as we need to calculate all edges
			for (l = 0; l < numClusters; l++)
				residualUsers[l] = numUsersPerCluster[l];
			for (l = 0; l < numHoverLocations; l++)
				residualUAVCap[l] = CapUAV;
			// adding the new edges into all deployed array
			for (l = 0; l < numInitialSumEdges[bestNextLoc]; l++)
			{
				allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLoc][l];
				numDeployedEdges++;
			}
			// calculating the total throughput
			sort(allDeployedEdges, allDeployedEdges + numDeployedEdges, cmp);
			for (l = 0; l < numDeployedEdges; l++)
			{
				bestClusterID = allDeployedEdges[l].userID;
				bestLocationID = allDeployedEdges[l].locationID;
				bestMinCap = residualUsers[bestClusterID];
				if (residualUAVCap[bestLocationID] < bestMinCap)
					bestMinCap = residualUAVCap[bestLocationID];
				// the total throughput after adding the best location
				bestAssignedThroughput += bestMinCap * allDeployedEdges[l].dataRate;
				
				residualUAVCap[bestLocationID] -= bestMinCap;
				residualUsers[bestClusterID] -= bestMinCap;
			}
			profitEachLocation[bestNextLoc] = bestAssignedThroughput - sumAssignedThroughput;
			// printf("the sum throughput now is %.2lf, the best throughput now is %.2lf, the best location is %d and its profit is %.2lf\n", sumAssignedThroughput, bestAssignedThroughput, bestNextLoc, profitEachLocation[bestNextLoc]);
			sumAssignedThroughput = bestAssignedThroughput;

			if (bestAssignedThroughput == 0) break;
		}
		// the operation of assigning profit finishes

		// initial one node
		for (i = 0; i < numHoverLocations; ++i)
		{
			for (k = 0; k < numHoverLocations; ++k)	isToDeployUAV[k] = false;
			numDeployedLocations = 1;
			hoverLocations[0] = i;
			isToDeployUAV[i] = true;
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
			int minDis;
			int nearestNode;
			// Find the shortest distances and paths to the nodes already in the subtree
			for (k = 0; k < numHoverLocations; ++k)
			{
				// printf("isToDeployUAV is %d\n", isToDeployUAV[halfDHops[test1]]); // 调试
				if (true == isToDeployUAV[k]) continue;
				minDis = 1000000;
				for (l = 0; l < numDeployedLocations; ++l)
				{
					v = hoverLocations[l];
					if (minHops[k][v] < minDis)
					{
						minDis = minHops[k][v];
						nearestNode = v;
					}
				}
				MinDistances[k] = minDis;
				allNearestNodes[k] = nearestNode;
			}

			// initial throughput
			double totalThroughput = 0;
			for (l = 0; l < numDeployedLocations; ++l)
				totalThroughput += profitEachLocation[hoverLocations[l]];
			// printf("initial total is %d\n", totalUsers);

			int bestNextLocation;
			double bestTestThroughput;
			double curTestThroughput;
			double bestRatio;
			int nextNode;
			int testNode;

			while (numDeployedLocations < numUAVs)
			{
				// bestRatio = -1;
				bestTestThroughput = -1;
				for (testNode = 0; testNode < numHoverLocations; ++testNode)
				{
					if (true == isToDeployUAV[testNode]) continue;
										
					// version : neighbor
					if (MinDistances[testNode] >= 2) continue;  // do not see the nodes that are far away
					hoverLocations[numDeployedLocations] = testNode;
					numDeployedLocations++;
					curTestThroughput = profitEachLocation[testNode];
					if (curTestThroughput > bestTestThroughput)
					{
						bestTestThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}
					--numDeployedLocations;
					
					// version : far away node
					/*if (numDeployedLocations + MinDistances[testNode] > numUAVs) continue;
					hoverLocations[numDeployedLocations] = testNode;
					numDeployedLocations++;
					nearestNode = allNearestNodes[testNode];
					v = testNode;
					curTestThroughput = profitEachLocation[testNode];
					while (nearestNode != allParentSPT[nearestNode][v]) // not the root of the tree
					{
						nextNode = allParentSPT[nearestNode][v];
						hoverLocations[numDeployedLocations] = nextNode;
						++numDeployedLocations;
						v = nextNode;
						curTestThroughput += profitEachLocation[nextNode];
					}

					if (1.0 * curTestThroughput / (double)minHops[i][testNode] > bestRatio)
					{
						bestRatio = 1.0 * curTestThroughput / (double)minHops[i][testNode];
						bestTestThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}*/
					/*if (curTestThroughput > bestTestThroughput)
					{
						bestTestThroughput = curTestThroughput;
						bestNextLocation = testNode;
					}*/
					
					// numDeployedLocations -= MinDistances[testNode];
				}
		
				// added the nodes on the shortest path
				
				// version :neighbor
				hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;

				// veirsion :far away node
				/*hoverLocations[numDeployedLocations] = bestNextLocation;
				numDeployedLocations++;
				isToDeployUAV[bestNextLocation] = true;
				nearestNode = allNearestNodes[bestNextLocation];
				v = bestNextLocation;
				while (nearestNode != allParentSPT[nearestNode][v])
				{
					nextNode = allParentSPT[nearestNode][v];
					hoverLocations[numDeployedLocations] = nextNode;
					isToDeployUAV[nextNode] = true;
					++numDeployedLocations;
					v = nextNode;
				}*/
				totalThroughput += bestTestThroughput;

				//update the shortest paths and distances
				for (l = 0; l < numHoverLocations; ++l)
				{
					if (true == isToDeployUAV[l]) continue;
					for (k = numDeployedLocations - MinDistances[bestNextLocation]; k < numDeployedLocations; ++k)
					{
						v = hoverLocations[k];

						if (minHops[l][v] < MinDistances[l])
						{
							MinDistances[l] = minHops[l][v];
							allNearestNodes[l] = v;
						}
					}
				}
			}
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
			if (maxThroughput < totalThroughput)
			{
				maxThroughput = totalThroughput;
				bestNumHoveringLocations = numDeployedLocations;
				for (l = 0; l < numDeployedLocations; ++l)
					bestHoveringLocations[l] = hoverLocations[l];
			}
		}
	}
	numDeployedLocations = bestNumHoveringLocations;
	for (i = 0; i < numDeployedLocations; ++i)
	{
		hoverLocations[i] = bestHoveringLocations[i];
		// printf("the location is %d\n", hoverLocations[i]);
	}
	maxThroughput = calMaxThroughput();
	return maxThroughput;
}

double maxUAVCoverage::ApproAlgShort()
{
	int i, j, k, l, m;
	double maxThroughput = 0;
	// int loop_time = 0;

	int minHopsA = 0, minHopsB = 0, minHopsC = 0, minSum = 0;
	int s1 = 0, t1 = 0, s2 = 0, t2 = 0;
	int u, v;
	int MinDistances[numHoverLocations];
	int allNearestNodes[numHoverLocations];

	int updateClusterID = 0;
	int updateLocationID = 0;
	int updateMinCap = 0;

	double totalThroughput;
	double bestRatio;

	int numDeployedEdges;
	int clusterID = 0;
	int minCap = 0;
	int locationID = 0;
	
	// initial three nodes
	for (i = 0; i < numHoverLocations; ++i)
	{
		for (j = i + 1; j < numHoverLocations; ++j)
		{
			for (k = j + 1; k < numHoverLocations; ++k)
			{
				minHopsA = minHops[i][j] + minHops[i][k];
				minHopsB = minHops[i][j] + minHops[j][k];
				minHopsC = minHops[j][k] + minHops[i][k];
				// keep t1 = t2
				if (minHopsA <= minHopsB) {
					minSum = minHopsA;
					s1 = j;
					t1 = i;
					s2 = k;
					t2 = i;
				}else {
					minSum = minHopsB;
					s1 = i;
					t1 = j;
					s2 = k;
					t2 = j;
				}
				if (minSum > minHopsC) {
					minSum = minHopsC;
					s1 = j;
					t1 = k;
					s2 = i;
					t2 = k;
				}
				if (minSum > numUAVs - 1) continue;
				for (l = 0; l < numHoverLocations; ++l)	isToDeployUAV[l] = false;
				numDeployedLocations = 1;
				hoverLocations[0] = s2;
				isToDeployUAV[s2] = true;
				v = s2;
				while (-1 != allParentSPT[t2][v])
				{
					u = allParentSPT[t2][v];
					hoverLocations[numDeployedLocations] = u;
					++numDeployedLocations;
					isToDeployUAV[u] = true;
					v = u;
				}
				hoverLocations[numDeployedLocations] = s1;
				numDeployedLocations++;
				isToDeployUAV[s1] = true;
				v = s1;
				while (t1 != allParentSPT[t1][v])
				{
					u = allParentSPT[t1][v]; // t1 = t2
					if (false == isToDeployUAV[u]){
						hoverLocations[numDeployedLocations] = u;
						++numDeployedLocations;
						isToDeployUAV[u] = true;
					}
					v = u;
				}
//-----------------------------------------------------------------extendByGreedy---------------------------------------------------------------------------------------					
//-----------------------------------------------------------------extendByGreedy---------------------------------------------------------------------------------------				
//-----------------------------------------------------------------extendByGreedy---------------------------------------------------------------------------------------
				// Find the shortest distances and paths to the nodes already in the subtree
				int minDis;
				int nearestNode;
				for (m = 0; m < numHoverLocations; ++m)
				{
					if (true == isToDeployUAV[m]) continue;
					minDis = 1000000;
					for (l = 0; l < numDeployedLocations; ++l)
					{
						v = hoverLocations[l];
						if (minHops[m][v] < minDis)
						{
							minDis = minHops[m][v];
							nearestNode = v; // when the extension node is not always neighbours
						}
					}
					MinDistances[m] = minDis;
					allNearestNodes[m] = nearestNode; // when the extension node is not always neighbours
				}

				//********* if the tree extension only calculating the test node and,
				//********* the total throughput will be recalculating when finding the best location, then,
				//********* the initial total throughput need not to be calculate
				int deployedLocation = 0;
				numDeployedEdges = 0;
				for (m = 0; m < numClusters; ++m)
					residualUsers[m] = numUsersPerCluster[m];
				for (l = 0; l < numHoverLocations; ++l)
					residualUAVCap[l] = CapUAV;
				for(m = 0; m < numDeployedLocations; m++)
				{
					deployedLocation = hoverLocations[m];
					for (l = 0; l < numInitialSumEdges[deployedLocation]; l++)
					{
						allDeployedEdges[numDeployedEdges] = preAllEdges[deployedLocation][l];
						numDeployedEdges++;
					}
				}
				// calculating initial throughput
				/*sort(allDeployedEdges, allDeployedEdges+numDeployedEdges, cmp);
				totalThroughput = 0;
				for(m = 0; m < numDeployedEdges; m++)
				{
					clusterID = allDeployedEdges[m].userID;
					locationID = allDeployedEdges[m].locationID;
					minCap = residualUsers[clusterID];

					if (residualUAVCap[locationID] < minCap)
						minCap = residualUAVCap[locationID];

					totalThroughput += minCap * allDeployedEdges[m].dataRate;
					// printf("the totalthroughput now is %2lf\n", totalThroughput);
					residualUsers[clusterID] -= minCap;
					residualUAVCap[locationID] -= minCap;
				}*/
				// printf("the initial nodes are %d\t, %d\t, %d\t, and the initial totoalThroughput is %.2lf\n", i, j, k, totalThroughput);

				// tree extention
				int bestNextLocation;
				double bestIncreasedThroughput;
				double curTestThroughput;
				int testNode;
				int nextNode = 0;
				int numTestLocations = 0;
				int numUpdateLocations = 0;
				int updateDeployedLocation = 0;
				int testDeployedLocation = 0;

				int testSumNum = 0;
				int testClusterID = 0;
				int testLocationID = 0;
				int testMinCap = 0;
				while (numDeployedLocations < numUAVs)
				{
					bestIncreasedThroughput = -1;
					// bestRatio = -1;
					for (testNode = 0; testNode < numHoverLocations; ++testNode)
					{
						if (true == isToDeployUAV[testNode]) continue;
						if (MinDistances[testNode] >= 2) continue;  // neighbours
						
						// version of : the node of not only neighbors
						// start for all node + shortest path node/minDisntance
						// if (numDeployedLocations + MinDistances[testNode] > numUAVs) continue;
						// dierectly calculating all the nodes on the shortest path
						
						/*numTestLocations = numDeployedLocations; // saving the number before testing
						// printf("the number of deployed locations is %d\n", numTestLocations);
						hoverLocations[numDeployedLocations] = testNode;
						numDeployedLocations++;
						nearestNode = allNearestNodes[testNode];
						v = testNode;
						while (nearestNode != allParentSPT[nearestNode][v])
						{
							nextNode = allParentSPT[nearestNode][v];
							hoverLocations[numDeployedLocations] = nextNode;
							++numDeployedLocations;
							v = nextNode;
						}
						// printf("the number of deployed locations is %d\n", numDeployedLocations);
						testSumNum = 0;
						curTestThroughput = 0;
						for (l = numTestLocations; l < numDeployedLocations; l++)
						{
							testDeployedLocation = hoverLocations[l];
							for (m = 0; m < numInitialSumEdges[testDeployedLocation]; m++)
							{
								testNodeEdges[testSumNum] = preAllEdges[testDeployedLocation][m];
								testSumNum++;
							}
						}
						// printf("the number of edges of node %d is %d\n", testNode, testSumNum);
						sort(testNodeEdges, testNodeEdges + testSumNum, cmp);
						for (l = 0; l < testSumNum; l++)
						{
							testClusterID = testNodeEdges[l].userID;
							testLocationID = testNodeEdges[l].locationID;
							testMinCap = residualUsers[testClusterID];
							if (residualUAVCap[testLocationID] < testMinCap)
								testMinCap = residualUAVCap[testLocationID];
							curTestThroughput += testMinCap * testNodeEdges[l].dataRate;
							residualUAVCap[testLocationID] -= testMinCap;
						}
						//version 3 : comparing nodes on the shortest path / minDistances increment
						if (1.0 * curTestThroughput / (double)(numDeployedLocations - numTestLocations) > bestRatio)
						{
							bestRatio = 1.0 * curTestThroughput / (double)(numDeployedLocations - numTestLocations);
							bestNextLocation = testNode;
						}*/
						// numDeployedLocations = numTestLocations; // attention !!!!!!!!!!!!!
						 // end for all node + shortest path node/minDisntance
						
						// the following segment is infeasible due to the time complexity of the algorithm
						/*curTestThroughput = calMaxThroughput();
						// printf("the current throughput is %.2lf\n", curTestThroughput);
						numDeployedLocations = numTestLocations; // attention !!!!!!!!!!!!!
						// printf("the number of deployed locations is %d\n", numDeployedLocations);
						if (1.0 * (curTestThroughput - totalThroughput) / (double)minHops[i][testNode] > bestRatio)
						{
							bestRatio = 1.0 * (curTestThroughput - totalThroughput) / (double)minHops[i][testNode];
							bestNextLocation = testNode;
						}*/


						// start the version of only calculating the test node
						// integrated with version 1 and version 2
						testSumNum = 0;
						curTestThroughput = 0;

						for (l = 0; l < numInitialSumEdges[testNode]; l++)
						{
							testNodeEdges[l] = preAllEdges[testNode][l];
							testSumNum++;
						}
						// printf("the number of edges of node %d is %d\n", testNode, testSumNum);
						sort(testNodeEdges, testNodeEdges + testSumNum, cmp);
						for (l = 0; l < testSumNum; l++)
						{
							testClusterID = testNodeEdges[l].userID;
							testMinCap = residualUsers[testClusterID];
							if (residualUAVCap[testNode] < testMinCap)
								testMinCap = residualUAVCap[testNode];
							curTestThroughput += testMinCap * testNodeEdges[l].dataRate;
							residualUAVCap[testNode] -= testMinCap;
						}
						// printf("the throughput add by location %d is %.2lf\n", testNode, curTestThroughput);

						// version 1 : comparing testnode increment
						if (curTestThroughput > bestIncreasedThroughput)
						{
							bestIncreasedThroughput = curTestThroughput;
							bestNextLocation = testNode;
						}

						// version 2 : comparing testnode / minDistances increment
						/*if (1.0 * curTestThroughput / (double)MinDistances[testNode] > bestRatio)
						{
							bestRatio = 1.0 * curTestThroughput / (double)MinDistances[testNode];
							bestNextLocation = testNode;
						}*/
						// finish the version of only calculating the test node 
					}
					
					if (bestIncreasedThroughput == 0) break;
					// if (bestRatio == 0) break;
										
					// numUpdateLocations = numDeployedLocations; // record the numbers before adding
					// add the neighbor node
					hoverLocations[numDeployedLocations] = bestNextLocation;
					numDeployedLocations++;
					isToDeployUAV[bestNextLocation] = true;
					
					// add the nodes on the shortest path
					/*nearestNode = allNearestNodes[bestNextLocation];
					v = bestNextLocation;
					while (nearestNode != allParentSPT[nearestNode][v])
					{
						nextNode = allParentSPT[nearestNode][v];
						hoverLocations[numDeployedLocations] = nextNode;
						isToDeployUAV[nextNode] = true;
						++numDeployedLocations;
						v = nextNode;
					}*/
					
					// version for calculating all edges as follows
					// update the new edges, test arrays and residual users/caps
					/*totalThroughput += bestIncreasedThroughput;
					for (l = 0; l < numInitialSumEdges[bestNextLocation]; l++)
					{
						allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLocation][l];
						numDeployedEdges++;
					}*/
					// finish the version of calculating all edges

					// version : choosing edges of test node
					for (l = 0; l < numInitialSumEdges[bestNextLocation]; l++)
					{
						allDeployedEdges[numDeployedEdges] = preAllEdges[bestNextLocation][l];
						numDeployedEdges++;
					}

					// version : choosing edges of the nodes on the shortest path
					/*for (l = numUpdateLocations; l < numDeployedLocations; l++)
					{
						updateDeployedLocation = hoverLocations[l];
						for (m = 0; m < numInitialSumEdges[updateDeployedLocation]; m++)
						{
							allDeployedEdges[numDeployedEdges] = preAllEdges[updateDeployedLocation][m];
							numDeployedEdges++;
						}
					}*/
					sort(allDeployedEdges, allDeployedEdges + numDeployedEdges, cmp);
					for (l = 0; l < numClusters; l++)
						residualUsers[l] = numUsersPerCluster[l];
					for(l = 0; l < numHoverLocations; l++)
						residualUAVCap[l] = CapUAV;
					// recalculating the total throughput
					totalThroughput = 0;
					for (l = 0; l < numDeployedEdges; l++)
					{
						updateClusterID = allDeployedEdges[l].userID;
						updateLocationID = allDeployedEdges[l].locationID;
						updateMinCap = residualUsers[updateClusterID];
						if (residualUAVCap[updateLocationID] < updateMinCap)
							updateMinCap = residualUAVCap[updateLocationID];
						
						totalThroughput += updateMinCap * allDeployedEdges[l].dataRate;
						residualUsers[updateClusterID] -= updateMinCap;
						residualUAVCap[updateLocationID] -= updateMinCap;
					}
					// finish the version of updating the only calculating test node
	
					//update the shortest paths and distances
					for (l = 0; l < numHoverLocations; ++l)
					{
						if (true == isToDeployUAV[l]) continue;
						for (m = numDeployedLocations - MinDistances[bestNextLocation]; m < numDeployedLocations; ++m)
						{
							v = hoverLocations[m];
							if (minHops[l][v] < MinDistances[l])
							{
								MinDistances[l] = minHops[l][v];
								allNearestNodes[l] = v;
							}
						}
					}
				}
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------						
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
//-----------------------------------------------------------------extendByGreedy----------------------------------------------------------------------------------------	
				if (maxThroughput < totalThroughput)
					maxThroughput = totalThroughput;
				//if (loop_time % 50000 == 0) printf("loop time: %d, time: %.2lf seconds\n", loop_time, (clock() - st) / 1000.0);
			}
		}
	}
	return maxThroughput;
}

double maxUAVCoverage::AlgTreeDecomp()
{
	int i, j, k;

	double profit;
	double dis;

	int userID = 0;
	// first assign the profit of each hovering locations as the number of users it covers
	for (i = 0; i < numHoverLocations; ++i) 
	{
		profit = 0;
		/*for (j = 0; j < numClusters; ++j)
		{
			dis = distance2D(xHoverLoc[i], yHoverLoc[i], xCluster[j], yCluster[j]);
			if (dis <= userCommRadius) // within communication range
				profit += numUsersPerCluster[j];
		}
		profitEachLocation[i] = profit;  */
		for (j = 0; j < numInitialSumEdges[i]; j++)
		{
			userID = preAllEdges[i][j].userID;
			profit += numUsersPerCluster[userID] * preAllEdges[i][j].dataRate;
		}
		profitEachLocation[i] = profit;
		
		if( verbose )
			printf("location %d, covered users: %lf\n", i, profit);
	}

	/*bool isLabelled[numHoverLocations];
	for (i = 0; i < numHoverLocations; ++i) isLabelled[i] = false;
	bool isCovered[numClusters];
	for (i = 0; i < numClusters; ++i) isCovered[i] = false;

	int sumCovered = 0;
	int bestIncreaseCovered;
	int bestNextLoc;
	int curCovered;
	
	// assign profit for each hovering location
	for (i = 0; i < numHoverLocations; ++i)  // increase the profit of each location by the greedy maximum coverage approach
	{
		bestIncreaseCovered = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isLabelled[j]) continue;

			curCovered = 0;
			for (k = 0; k < numClusters; ++k)
			{
				if (true == isCovered[k]) continue;
				dis = distance2D(xHoverLoc[j], yHoverLoc[j], xCluster[k], yCluster[k]);
				if (dis <= userCommRadius)
					curCovered += numUsersPerCluster[k];
			}

			if (curCovered > bestIncreaseCovered)
			{
				bestIncreaseCovered = curCovered;
				bestNextLoc = j;
			}
		}
		isLabelled[bestNextLoc] = true;
		profitEachLocation[bestNextLoc] = bestIncreaseCovered;
		for (k = 0; k < numClusters; ++k)
		{
			if (true == isCovered[k]) continue;
			dis = distance2D(xHoverLoc[bestNextLoc], yHoverLoc[bestNextLoc], xCluster[k], yCluster[k]);
			if (dis <= userCommRadius)	isCovered[k] = true; // this is covered now
		}
		
		sumCovered += bestIncreaseCovered;
		printf("%d th node, assign profit to node %d, profit: %d, total profit: %d\n", i + 1, bestNextLoc, bestIncreaseCovered, profitEachLocation[bestNextLoc]);
	}*/
	// the operation of assigning profit finishes
	// the hovering locations that cover many users are assigned higher profits

	int maxThroughput = 0;
	int curThroughput;
	for (i = 0; i < numHoverLocations; ++i)
	{
		numDeployedLocations = 1;
		hoverLocations[0] = i;
		for (j = 0; j < numHoverLocations; ++j)	isToDeployUAV[j] = false;
		isToDeployUAV[i] = true;

		extendByGreedyProfitLabel();
		curThroughput = calMaxThroughput();
		if (maxThroughput < curThroughput)
		{
			maxThroughput = curThroughput;
		}
		//if (i % 100 == 0 && i > 0) printf("%d th loop\n", i + 1);
	}
	return maxThroughput;
}

void maxUAVCoverage::extendByGreedyProfitLabel()
{
	int i, j;
	int u, v;
	// double totalThroughput;

	int minDis;
	for (i = 0; i < numHoverLocations; ++i)
	{
		if (true == isToDeployUAV[i]) continue;
		minDis = 1000000;
		for (j = 0; j < numDeployedLocations; ++j)
			if (true == adjMatrix[i][hoverLocations[j]])
				minDis = 1;
		nearestEdgeWeight[i] = minDis;
	}
	/*totalThroughput = 0;
	for (i = 0; i < numDeployedLocations; ++i)
		totalThroughput += profitEachLocation[hoverLocations[i]];*/
	
	double curIncreasedThroughput;
	double bestIncreasedThroughput;
	int bestNextLocation;
	while (numDeployedLocations < numUAVs)
	{
		bestIncreasedThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isToDeployUAV[j]) continue;
			if (nearestEdgeWeight[j] >= 2) continue; // not adjacent

			hoverLocations[numDeployedLocations] = j;
			numDeployedLocations++;

			curIncreasedThroughput = profitEachLocation[j];
			if (curIncreasedThroughput > bestIncreasedThroughput)
			{
				bestIncreasedThroughput = curIncreasedThroughput;
				bestNextLocation = j;
			}

			--numDeployedLocations;
		}
		if (-1 == bestIncreasedThroughput) break;

		hoverLocations[numDeployedLocations] = bestNextLocation;
		numDeployedLocations++;
		// totalThroughput += bestIncreasedThroughput;

		isToDeployUAV[bestNextLocation] = true;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isToDeployUAV[j]) continue;
			if (true == adjMatrix[bestNextLocation][j])
				nearestEdgeWeight[j] = 1;
		}
	}
	// return totalThroughput;
}

void maxUAVCoverage::findShortestPath(int s)
{
	int sz = numHoverLocations;
	int i, j;

	for (i = 0; i < sz; ++i) visited[i] = false;
	for (i = 0; i < sz; ++i) parentSPT[i] = -1;
	visited[s] = true;
	queue_clear();
	queue_push(s);

	int u;
	while (queue_size() >0)
	{
		u = queue_pop();
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (false == adjMatrix[u][j]) continue;
			if (true == visited[j]) continue;

			queue_push(j);
			visited[j] = true;
			parentSPT[j] = u;
			//allParentSPT[s][j] = u;
		}
	}
}

void maxUAVCoverage::findAllShortestPath()
{
	int i, j;
	
	for (i = 0; i < numHoverLocations; ++i)
	{
		findShortestPath(i);
		for (j = 0; j < numHoverLocations; ++j)
		{
			allParentSPT[i][j] = parentSPT[j];
		}
	}
}

void maxUAVCoverage::initialization()
{
	assignUserLocations();
	assignHoverLocatoins();
	findMinHopsAmongLocations();
	findAllShortestPath();
	calAvgDataRates();
	preCalEdges();
	//calUsersCoveredPerLocation(); 
}

void maxUAVCoverage::findMinHopsAmongLocations()
{
	
	bool visited[numHoverLocations];
	int minDis[numHoverLocations];
	int i, j;

	for (i = 0; i < numClusters; ++i)
		for (j = 0; j < numHoverLocations; ++j)
			disMatrix[i][j] = distance2D(xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j]);
	
	for (i = 0; i < numHoverLocations; ++i)
	{	
		queue_clear();
		queue_push(i); // mininum hops from node i to other nodes, by applying BFS
		for (j = 0; j < numHoverLocations; ++j) visited[j] = false;
		visited[i] = true;
		for (j = 0; j < numHoverLocations; ++j) minDis[j] = 99999;
		minDis[i] = 0;

		int v;
		while (queue_size() > 0)
		{
			v = queue_pop();
			for (j = 0; j < numHoverLocations; ++j)
			{
				if (true == visited[j]) continue;
				if (distance2D(xHoverLoc[v], yHoverLoc[v], xHoverLoc[j], yHoverLoc[j]) <= R)
				{
					minDis[j] = minDis[v] + 1;
					visited[j] = true;
					queue_push(j);
				}
			}
		}
		for (j = 0; j < numHoverLocations; ++j)
			minHops[i][j] = minDis[j];
	}

	for (i = 0; i < numHoverLocations; ++i)
		for (j = 0; j < numHoverLocations; ++j)
			adjMatrix[i][j] = false;
	for (i = 0; i < numHoverLocations; ++i)
		for (j = i + 1; j < numHoverLocations; ++j)
			if (distance2D(xHoverLoc[i], yHoverLoc[i], xHoverLoc[j], yHoverLoc[j]) <= R)
				adjMatrix[i][j] = adjMatrix[j][i] = true;
}

void maxUAVCoverage::assignUserLocations()
{
	double con = (double)numUsers / (log2(numClusters) / log2(2.35));
	int i;
	int sumUsers = 0, curUsers;
	for (i = 1; i < numClusters; ++i)
	{
		curUsers = (int)ceil(con / i); // zipf distribution
		if (sumUsers + curUsers > numUsers)
			curUsers = numUsers - sumUsers;
		numUsersPerCluster[i - 1] = curUsers;
		sumUsers += curUsers;

	}
	numUsersPerCluster[numClusters - 1] = numUsers - sumUsers;

	xCluster[0] = 0; yCluster[0] = 0;
	xCluster[1] = L; yCluster[1] = W;
	xCluster[2] = 0; yCluster[2] = W;
	xCluster[3] = L; yCluster[3] = 0;
	for (i = 4; i < numClusters; ++i)
	{
		xCluster[i] = L * Uniform();
		yCluster[i] = W * Uniform();
	}

	if (testPrint)
	{
		for (i = 0; i < numClusters; ++i)
			printf("cluster %d, users: %d, x: %.0lf,\ty: %.lf\n", i, numUsersPerCluster[i], xCluster[i], yCluster[i]);
	}
}

void maxUAVCoverage::assignHoverLocatoins()
{
	int rows = L / delta;
	int cols = W / delta;
	int i, j;
	int index = 0;
	for (i = 0; i < rows; ++i)
		for (j = 0; j < cols; ++j)
		{
			xHoverLoc[index] = delta / 2 + i*delta;
			yHoverLoc[index] = delta / 2 + j*delta;
			index++;
		}
	for (i = 0; i < numClusters; ++i, ++index)
	{
		xHoverLoc[index] = xCluster[i];
		yHoverLoc[index] = yCluster[i];
	}


	/*double x, y;
	for (i = 0; i < 1; ++i, index += 4)
	{
		//consider the 2 clusters with the most people
		x = xCluster[i] - 100; // the left nearby location
		if (x < 0) x = 0;
		y = yCluster[i];
		xHoverLoc[index] = x;
		yHoverLoc[index] = y;

		x = xCluster[i] + 100; // the right nearby location
		if (x > L) x = L;
		y = yCluster[i];
		xHoverLoc[index + 1] = x;
		yHoverLoc[index + 1] = y;

		x = xCluster[i];
		y = yCluster[i] - 100; // the bottom nearby location
		if (y < 0) y = 0;
		xHoverLoc[index + 2] = x;
		yHoverLoc[index + 2] = y;

		x = xCluster[i];
		y = yCluster[i] + 100; // the top nearby location
		if (y > W) y = W;
		xHoverLoc[index + 3] = x;
		yHoverLoc[index + 3] = y;
	}*/

	int numShifts[4] = {4, 3, 2, 1};
	//int numShifts[1] = {1}; 
	// Pls modify the variable `numHoverLocations' if changing values in the array
	int shift = 50; // meters;
	
	//consider the 5 clusters with the most people
	for (i = 0; i < 4; ++i)
	{
		for (j = 1; j <= numShifts[i]; ++j)
		{
			xHoverLoc[index] = xCluster[i] - j * shift; // the left nearby locations
			yHoverLoc[index] = yCluster[i];
			if (verbose)
				{printf("location %d, x: %.lf\t, y: %.lf\t, numShift[i]: %d\n", index, xHoverLoc[index], yHoverLoc[index], numShifts[i]);}
			++index;
		}
		for (j = 1; j <= numShifts[i]; ++j)
		{
			xHoverLoc[index] = xCluster[i] + j * shift; // the right nearby locations
			yHoverLoc[index] = yCluster[i];
			if (verbose)
				{printf("location %d, x: %.lf\t, y: %.lf\t, numShift[i]: %d\n", index, xHoverLoc[index], yHoverLoc[index], numShifts[i]);}
			++index;
		}
		for (j = 1; j <= numShifts[i]; ++j)
		{
			xHoverLoc[index] = xCluster[i]; 
			yHoverLoc[index] = yCluster[i] - j * shift; // the bottom nearby locations
			if (verbose)
				{printf("location %d, x: %.lf\t, y: %.lf\t, numShift[i]: %d\n", index, xHoverLoc[index], yHoverLoc[index], numShifts[i]);}
			++index;
		}
		for (j = 1; j <= numShifts[i]; ++j)
		{
			xHoverLoc[index] = xCluster[i];
			yHoverLoc[index] = yCluster[i] + j * shift; // the top nearby locations
			if (verbose)
				{printf("location %d, x: %.lf\t, y: %.lf\t, numShift[i]: %d\n", index, xHoverLoc[index], yHoverLoc[index], numShifts[i]);}
			++index;
		}
	}

	if (testPrint)
	{
		for (i = 0; i < numHoverLocations; ++i) 
			printf("location %d, x: %.lf\t, y: %.lf\n", i, xHoverLoc[i], yHoverLoc[i]);
	}
}

void maxUAVCoverage::calUsersCoveredPerLocation()
{
	int i, j;
	for (i = 0; i < numHoverLocations; ++i) 
	{
		numLocCoverClusters[i] = 0;
		for (j = 0; j < numClusters; ++j)
		{
			if (disMatrix[j][i] <= userCommRadius)
			{
				locCoverSpecCluster[i][numLocCoverClusters[i]] = j;
				++numLocCoverClusters[i];
			}
		}
	}
}

int maxUAVCoverage::calDeployedCoverUsers()
{
	int i, j;
	int lessCap;
	int sumUsersCovered = 0;

	for (i = 0; i < numClusters; ++i)
		residualUsers[i] = numUsersPerCluster[i];
	for (j = 0; j < numHoverLocations; ++j)	
		residualUAVCap[j] = CapUAV;
	
	int clusterId = 0;
	int uavCap;
	for (i = 0; i < numDeployedLocations; ++i)
	{
		uavCap = residualUAVCap[hoverLocations[i]];
		for (j = 0; j < numLocCoverClusters[hoverLocations[i]]; ++j)
		{
			clusterId = locCoverSpecCluster[hoverLocations[i]][j];
			//if (0 == residualUsers[clusterId]) continue;
			//if (0 == residualUAVCap[hoverLocations[i]]) break;
			lessCap = residualUsers[clusterId];
			if (lessCap > uavCap)
				lessCap = uavCap;
			sumUsersCovered += lessCap;
			uavCap -= lessCap;
			residualUsers[clusterId] -= lessCap;
			//residualUAVCap[hoverLocations[i]] -= lessCap;	
		}
	}
	return sumUsersCovered;
}