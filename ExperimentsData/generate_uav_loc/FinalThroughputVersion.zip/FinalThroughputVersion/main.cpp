#include<stdio.h>
#include<assert.h>
#include<math.h>
#include<time.h>
#include<iostream>
#include<fstream>
using namespace std;
#include "maxCoverageModified.h"


int main()
{
	int test_v = 1; // 1: vs network size; 2: vs numUAVs, 3: vs commRangeUAVs; 4: vs commRangeUsers, 5: vs CapUAV 6: vs Delta

	maxUAVCoverage maxCoverage;
	clock_t st, ft;
	int loop_times = 1;
	int loop;

	double numUsersCoveredAppro = 0;
	double timeAppro = 0;
	double approSumDis, approBestSumDis=0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredAppro += maxCoverage.ApproAlgTwo(approSumDis);
		// numUsersCoveredAppro  += maxCoverage.deepGreedyAlg(approSumDis);
		approBestSumDis += approSumDis;
	}
	ft = clock();
	numUsersCoveredAppro /= loop_times;
	approBestSumDis /= loop_times;
	timeAppro = (ft - st) / (1000.0 * loop_times);

	double numUsersCoveredMotionControl = 0;
	double timeMotionControl = 0;
	double MCsumDis, MCbestSumDis = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Motion Control Alg %d th loop...\n", loop + 1);
		srand(loop + 100);
		maxCoverage.initialization();
		numUsersCoveredMotionControl += maxCoverage.motionControlAlg(MCsumDis);
		MCbestSumDis += MCsumDis;
	}
	ft = clock();
	numUsersCoveredMotionControl /= loop_times;
	MCbestSumDis /= loop_times;
	timeMotionControl = (ft - st) / (1000.0 * loop_times);

	double numUsersCoveredDeepLearning = 0;
	double timeDeepLearning = 0;
	double DLsumDis, DLbestSumDis = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Deep Learning Alg %d th loop...\n", loop + 1);
		srand(loop + 100);
		maxCoverage.initialization();
		numUsersCoveredDeepLearning += maxCoverage.greedyAlg(DLsumDis);
		DLbestSumDis += DLsumDis;
	}
	ft = clock();
	numUsersCoveredDeepLearning /= loop_times;
	DLbestSumDis /= loop_times;
	timeDeepLearning = (ft - st) / (1000.0 * loop_times);

	double numUsersCoveredProfitLabel = 0;
	double timeProfitLabel = 0;
	double labelSumDis, labelBestSumDis = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Profit Label Alg %d th loop...\n", loop + 1);
		srand(loop + 100);
		maxCoverage.initialization();
		numUsersCoveredProfitLabel += maxCoverage.greedyProfitLabelAlg(labelSumDis);
		labelBestSumDis += labelSumDis;
	}
	ft = clock();
	numUsersCoveredProfitLabel /= loop_times;
	labelBestSumDis /= loop_times;
	timeProfitLabel = (ft - st) / (1000.0 * loop_times);

	double energyPerMeter = 11.89;
	// flying energy consumption per UAV
	approBestSumDis = energyPerMeter * approBestSumDis/(1000.0*numUAVs); 
	MCbestSumDis = energyPerMeter * MCbestSumDis / (1000.0 * numUAVs);
	DLbestSumDis = energyPerMeter * DLbestSumDis / (1000.0 * numUAVs);
	labelBestSumDis = energyPerMeter * labelBestSumDis / (1000.0 * numUAVs);

	printf("num of UAVs: %d\n", numUAVs);
	printf("throughput by Appro Alg: %.2lf Gbps, time: %.2lf sec, energy: %.2lf kJ\n", numUsersCoveredAppro/1000.0, timeAppro, approBestSumDis); 
	printf("throughput by MotCo Alg: %.2lf Gbps, time: %.2lf sec, energy: %.2lf kJ\n", numUsersCoveredMotionControl/1000.0, timeMotionControl, MCbestSumDis);
	printf("throughput by MCS   Alg: %.2lf Gbps, time: %.2lf sec, energy: %.2lf kJ\n", numUsersCoveredDeepLearning / 1000.0, timeDeepLearning, DLbestSumDis);
	printf("throughput by ProLa Alg: %.2lf Gbps, time: %.2lf sec, energy: %.2lf kJ\n", numUsersCoveredProfitLabel / 1000.0, timeProfitLabel, labelBestSumDis);
	
	
	ofstream resultFile[2];
	char fileName[2][100];
	switch (test_v) // 1: vs network size; 2: vs numUAVs, 3: vs commRangeUAVs; 4: vs commRangeUsers  5: vs CapUAV 6: vs Delta
	{
	case 1:  // 1: vs network size;
		sprintf(fileName[0], "vsNetworkSize-X-%d-%.0lf-%.0lf-numUsersCovered.txt", numUAVs, R, r);
		sprintf(fileName[1], "vsNetworkSize-X-%d-%.0lf-%.0lf-runningTime.txt", numUAVs, R, r);
		break;
	case 2:
		sprintf(fileName[0], "vsNumUAVs-%d-X-%.0lf-%.0lf-numUsersCovered.txt", numUsers, R, r);
		sprintf(fileName[1], "vsNumUAVs-%d-X-%.0lf-%.0lf-runningTime.txt", numUsers, R, r);
		break;
	case 3:
		sprintf(fileName[0], "vsCommRangeUAVs-%d-%d-X-%.0lf-numUsersCovered.txt", numUsers, numUAVs,  r);
		sprintf(fileName[1], "vsCommRangeUAVs-%d-%d-X-%.0lf-runningTime.txt", numUsers, numUAVs,  r);
		break;
	case 4:
		sprintf(fileName[0], "vsCommRangeUsers-%d-%d-%.0lf-X-numUsersCovered.txt", numUsers, numUAVs, R);
		sprintf(fileName[1], "vsCommRangeUsers-%d-%d-%.0lf-X-runningTime.txt", numUsers, numUAVs, R);
		break;
	case 5:
		sprintf(fileName[0], "vsCapUAV-%d-%d-%.0lf-%.0lf-numUsersCovered.txt", numUsers, numUAVs, R, r);
		sprintf(fileName[1], "vsCapUAV-%d-%d-%.0lf-%.0lf-runningTime.txt", numUsers, numUAVs, R, r);
		break;
	case 6:
		sprintf(fileName[0], "vsDelta-%d-%d-%.0lf-%.0lf-numUsersCovered.txt", numUsers, numUAVs, R, r);
		sprintf(fileName[1], "vsDelta-%d-%d-%.0lf-%.0lf-runningTime.txt", numUsers, numUAVs, R, r);
		break;
	default:
		abort();
	}

	int i;
	for (i = 0; i < 2; ++i)
		resultFile[i].open(fileName[i], ios::app);
	int parameters[7]; // 1: vs network size; 2: vs numUAVs, 3: vs commRangeUAVs; 4: vs commRangeUsers  5: vs CapUAV 6: vs Delta
	parameters[1] = numUsers;
	parameters[2] = numUAVs;
	parameters[3] = R;
	parameters[4] = r;
	parameters[5] = CapUAV;
	parameters[6] = delta;
	for (i = 0; i < 2; ++i)
		resultFile[i] << parameters[test_v] << '\t';

	resultFile[0]	<< numUsersCoveredAppro / 1000.0 << '\t'		<< numUsersCoveredMotionControl / 1000.0 << '\t'
					<< numUsersCoveredDeepLearning / 1000.0 << '\t'		<< numUsersCoveredProfitLabel / 1000.0 << '\n';

	resultFile[1] << timeAppro << '\t' << timeMotionControl << '\t'	<< timeDeepLearning << '\t'  << timeProfitLabel << '\n';

	for (i = 0; i < 2; ++i)
		resultFile[i].close();

	int c;
	cin >> c;

	return 1;
}

