#include<stdio.h>
#include<assert.h>
#include<math.h>
#include<time.h>
#include<iostream>
#include<fstream>
#include<ctime>
using namespace std;
#include "ThroughputVersion.h"

int main()
{
	
	/*if (verbose) // 输出assignUserLocations()结果
	{
		for (i = 0; i < numClusters; ++i)
			printf("cluster %d, users: %d, x: %.0lf,\ty: %.lf\n", i, numUsersPerCluster[i], xCluster[i], yCluster[i]);
	}
	
	if (verbose) // // 输出assignHoverLocatoins()结果
	{
		for (j = 0; j < numHoverLocations; ++j) 
			printf("location %d, x: %.lf\t, y: %.lf\n", j, xHoverLoc[j], yHoverLoc[j]);
	}	
	for (i = 0; i < numHoverLocations; ++i) 
	{
		printf("hover location %d covers %d clusters \n",i, numLocCoverClusters[i]);
		for (j = 0; j < numLocCoverClusters[i]; ++j)
		{
			printf("location %d covers the cluster %d\n",i, locCoverSpecCluster[j][i]);
		}
	}
	if (verbose) // 输出findMinHopsAmongLocations()结果
	{
		for (i = 0; i < numHoverLocations; ++i)
		{
			for (j = 0; j < numHoverLocations; ++j)
			{
				printf("locationX %d, locationY: %d, minHops: %d, adjMatrix: %s\n", i, j, minHops[i][j], adjMatrix[i][j] == true ? "true" : "false");
			}
		}
	}
	if (verbose)
	{
		for (i = 0; i < numHoverLocations; ++i) 
		{
			for (j = 0; j < numClusters; ++j)
			{
				printf("cluster %d is covered by location %d ? ----> %s because the distance is %.lf\n", j, i, isLocCoverUserMatrix[j][i] == true ? "true" : "false", disMatrix[j][i]);
			}
		}
	}*/



	int i, j, k, l, m, n;
	//srand(1);
	clock_t st, ft;
	maxUAVCoverage maxCoverage;

	int loop_times = 20;
	int loop;

	// ApproAlgShort
	double throughputByShort = 0;
	double timeApproAlgShort = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByShort += maxCoverage.ApproAlgShort();
	}
	ft = clock();
	throughputByShort /= 1024.0 * loop_times;
	timeApproAlgShort = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);


	
	// ApproAlgLong
	double throughputByLong = 0;
	double timeApproAlgLong = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByLong += maxCoverage.ApproAlgLong();
	}
	ft = clock();
	throughputByLong /= 1024.0 * loop_times;
	timeApproAlgLong = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);



	// AlgKnapsack
	double throughputByKnapsack = 0;
	double timeAlgKnapsack = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByKnapsack += maxCoverage.AlgKnapsack();
	}
	ft = clock();
	throughputByKnapsack /= 1024.0 * loop_times;
	timeAlgKnapsack = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);


	// AlgGreedy
	double throughputByGreedy = 0;
	double timeAlgGreedy = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByGreedy += maxCoverage.AlgGreedy();
	}
	ft = clock();
	throughputByGreedy /= 1024.0 * loop_times;
	timeAlgGreedy = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);

	// AlgAssign
	double throughputByAssign = 0;
	double timeAlgAssign = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByAssign += maxCoverage.AlgAssign();
	}
	ft = clock();
	throughputByAssign /= 1024.0 * loop_times;
	timeAlgAssign = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);


	// AlgTreeDecomp
	double throughputByTreeDecmp = 0;
	double timeAlgTreeDecomp = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		throughputByTreeDecmp += maxCoverage.AlgTreeDecomp();
	}
	ft = clock();
	throughputByTreeDecmp /= 1024.0 * loop_times;
	timeAlgTreeDecomp = (ft - st) / (double)(CLOCKS_PER_SEC * loop_times);
	
	//printf("Users communication: \t%.2lf\n", r);
	printf("the area is %d meters times %d meters\n", L, W);
	printf("num of UAVs: %d\n", numUAVs);
	printf("num of Users: %d\n", numUsers);
	printf("r is %d meters\n", (int)r);
	
	printf("total throughput by Short Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByShort, timeApproAlgShort); 
	printf("total throughput by Long Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByLong, timeApproAlgLong);
	printf("total throughput by Knapsack Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByKnapsack, timeAlgKnapsack);
	printf("total throughput by Greedy Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByGreedy, timeAlgGreedy);
	printf("total throughput by Assign Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByAssign, timeAlgAssign);
	printf("total throughput by TreeDecomp Alg: %.2lf Gbps, time: %.2lf sec\n", throughputByTreeDecmp, timeAlgTreeDecomp);
}
