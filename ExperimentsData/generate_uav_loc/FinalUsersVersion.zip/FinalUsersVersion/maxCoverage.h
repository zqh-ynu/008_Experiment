#include "nonUniformArray.h"
#include "queue.h"
#include<vector>
#include<algorithm>

double verbose = false;

const int L = 3000, W = 3000, h = 300; // the length and width of the monitor area, and the height (altitude) of UAVs
const int numUsers = 1000; // number of ground users.
const int numClusters = 40;
int numUsersPerCluster[numClusters];
double xCluster[numClusters], yCluster[numClusters];//40个元素的一维数组

double R = 600, r = 500; // the communication ranges between two UAVs and a ground user
//assert(h < r);
double userCommRadius = sqrt(r*r - h*h); // the user communication radius at altitude h

const int numUAVs = 30;

int CapUAV = 100; // the maximum number of users that a UAV can serve
const int delta = 300; // 300 meters
const int numHoverLocations = (L / delta)*(W / delta) +numClusters + 3 * 4;//为什么加后两项？？？？？？？
double xHoverLoc[numHoverLocations], yHoverLoc[numHoverLocations]; // the candidate hovering locations at altitude h
int minHops[numHoverLocations][numHoverLocations];//152行152列
bool adjMatrix[numHoverLocations][numHoverLocations];

double disMatrix[numClusters][numHoverLocations];//40行152列


bool isToDeployUAV[numHoverLocations];
int nearestEdgeWeight[numHoverLocations];

vector<int> sizeEachRowFlowGraph;//动态数组，大小可以根据需要动态调整
vector<int> sizeEachRowResidualGraph;//动态数组，大小可以根据需要动态调整

int hoverLocations[numHoverLocations];
int numDeployedLocations;

double Pt = -6; // transmission power of UAV (dB)
double gt = 5; // gain of UAV (dB)
double PN = -105; // noise power (dB)
double pl_cons = 40.4; // = 20 log_10 (4pi f_c /c), dB
double pl_fadingLOS = 1; // fading loss of los link
double pl_fadingNLOS = 20; // fading loss of NLOS link
double Bw = 2.5; // MHz

double avgDataRates[numClusters][numHoverLocations];

int residualUsers[numClusters], residualUAVCap[numHoverLocations];
struct Edge {
	int userID;
	int locationID;
	double dataRate;
};
Edge allEdges[numClusters * numUAVs];//一维数组，一共1200个元素，每个元素都是一个结构体
inline bool cmp(Edge & x, Edge& y) { return x.dataRate > y.dataRate; }// in decreasing order
//定义了一个比较函数，返回true则表示x大于y，x在y前面，即降序。

double distance2D(double x1, double y1, double x2, double y2)
{
	double dx = x1 - x2, dy = y1 - y2;
	return sqrt(dx*dx + dy * dy);
}

double distance3D(double x1, double y1, double z1, double x2, double y2, double z2)
{
	double dx = x1 - x2, dy = y1 - y2, dz = z1 - z2;
	return sqrt(dx * dx + dy * dy + dz * dz);
}

inline double Uniform()
{
	//return (rand() % Mode) / (double)Mode;
	return double(rand()) / RAND_MAX;//rand返回整数值，此处强制转换为double类型
}

struct flowGraphEdge{
	int v; // one neighbor
	int Cap; // capacity of edge (u,v)
	int flow; // flow of edge (u,v)
	flowGraphEdge(int id, int c, int f){ v = id; Cap = c; flow = f; }
	//在结构体内部定义一个名为 Edge 的函数，通常是为了提供结构体自身的操作或行为。
	//这样的函数可以直接访问和操作结构体的成员变量，方便在结构体内部进行相关操作。
	flowGraphEdge(int id, int c){ v = id; Cap = c; flow = 0; }
	flowGraphEdge(){ flow = 0; }
	~flowGraphEdge(){}
	//显式定义析构函数通常用于需要特定资源管理或清理逻辑的情况。
	//对于简单的结构体和类，使用默认生成的析构函数通常是足够的。

};

struct residualGraphEdge{
	int v; // one neighbor
	int Cap; // capacity of edge (u,v)
	residualGraphEdge(int id, int c){ v = id; Cap = c; }
	residualGraphEdge(){}
	~residualGraphEdge(){}
};

class maxUAVCoverage{


public:
	void initialization();
public:
	double ApproAlg(double & bestSumDis);
	double deepGreedyAlg(double &bestSumDis);

	double greedyAlg(double& bestSumDis);
	
	double greedyProfitLabelAlg(double& bestSumDis);
	double profitEachLocation[numHoverLocations];
	double extendByGreedyProfitLabel();

	double motionControlAlg(double& bestSumDis);
protected:
	void findShortestPath(int s, int t);
	double extendByGreedy(bool vb, double & sumDis);

	
protected:
	bool visited[1000];
	int parentSPT[1 + numClusters + numHoverLocations + 1];

public:
	void calAvgDataRates();
	double calMaxThroughput();
protected:
	void assignUserLocations();
	void assignHoverLocatoins();
	void findMinHopsAmongLocations();
public:
	nonUniformArray<flowGraphEdge> flowGraph;
	nonUniformArray<residualGraphEdge> residualGraph;
};

double maxUAVCoverage::calMaxThroughput()
//已经部署好了，最后计算吞吐量
//因此numDeployedLocations已经计算好了
{
	//assert(numDeployedLocations <= numUAVs);
	int i, j;
	int locationID;
	Edge oneEdge;
	int numEdges = 0;
	//all edges
	for (i = 0; i < numClusters; ++i)
	{
		oneEdge.userID = i;
		for (j = 0; j < numDeployedLocations; ++j)
		{
			locationID = hoverLocations[j];
			//assert(locationID >= 0 && locationID < numHoverLocations);
			if (disMatrix[i][locationID] > r) continue;
			oneEdge.locationID = locationID;
			// oneEdge.dataRate = avgDataRates[i][locationID];
			allEdges[numEdges] = oneEdge;
			numEdges++;
		}
	}
	if (0 == numEdges) return 0;
	sort(allEdges, allEdges+numEdges, cmp); // sort in decreasing order

	for (i = 0; i < numClusters; ++i)
		residualUsers[i] = numUsersPerCluster[i]; // 每群剩余未覆盖用户数量
	for (j = 0; j < numDeployedLocations; ++j)
		residualUAVCap[hoverLocations[j]] = CapUAV; // 每个无人机位置剩余承载量

	int userID;
	int k;
	int minCap;
	// double sumDataRates = 0;
	int sumCoveredUsers = 0;
	for (k = 0; k < numEdges; ++k)
	{
		// 对于某条边
		userID = allEdges[k].userID; // 连接的用户群ID
		locationID = allEdges[k].locationID; // 连接的位置ID
		minCap = residualUsers[userID]; // 该用户群的人数
		if (residualUAVCap[locationID] < minCap) // 该位置剩余量 小于 该用户群人数
			minCap = residualUAVCap[locationID]; 
		// sumDataRates += minCap * allEdges[k].dataRate; // 该位置剩余量 大于 该用户群人数，直接计算
		sumCoveredUsers += minCap;

		residualUsers[userID] -= minCap; // 该用户群剩余未覆盖人数
		residualUAVCap[locationID] -= minCap; // 无人机剩余承载量
	}
	return sumCoveredUsers;
}

void maxUAVCoverage::calAvgDataRates()
{
	int i, j;
	double eucliDistance;
	double horizonalDistance;
	double pl_dis;
	double pl_los, pl_nlos;
	double SNR_los, SNR_nlos;
	double data_los, data_nlos;
	double angle;
	double a = 9.611725, b = 0.158062;
	double e = 2.71828;
	double prob_LOS;
	double dataRate;
	for(i=0; i<numClusters; ++i)
		for (j = 0; j < numHoverLocations; ++j)
		{
			horizonalDistance = distance2D( xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j]);
			eucliDistance = sqrt(horizonalDistance* horizonalDistance + double(h) * h);
			if (eucliDistance > r) {	avgDataRates[i][j] = 0;		continue; }

			pl_dis = 20.0 * log10(eucliDistance);

			pl_los =  pl_cons  + pl_dis +  pl_fadingLOS;
			SNR_los = pow(10.0, (Pt + gt - pl_los - PN)/10.0);
			data_los = Bw * log2(1.0 + SNR_los);

			pl_nlos = pl_cons + pl_dis + pl_fadingNLOS;
			SNR_nlos = pow(10.0, (Pt + gt - pl_nlos - PN) / 10.0);
			data_nlos = Bw * log2(1.0 + SNR_nlos);

			angle = 180.0 * asin(h / eucliDistance)/3.1415926; // elevation angle, in degree
			prob_LOS = 1.0 / (1.0 + a * pow(e, -b*(angle-a)));

			dataRate = prob_LOS * data_los + (1.0 - prob_LOS) * data_nlos;
			avgDataRates[i][j] = dataRate;
			if(verbose) printf("user: (%.0lf, %.0lf), uav:(%.0lf, %.0lf), dis: %.0lf, dataLoS: %.3lf, dataNLoS: %.3lf, angle: %.2lf, probLOS: %.3lf, avgDataRate: %.2lf Mbps\n ", xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j], eucliDistance, data_los, data_nlos, angle, prob_LOS, dataRate);
		}
}

double maxUAVCoverage::ApproAlg(double & bestSumDis)
{
	int i, j, k;
	double maxThroughput = 0;
	double curThroughput;
	double curSumDis;
	int loop_time = 0;
	for (i = 0; i < numHoverLocations; ++i)//循环行
	{
		for (j = i + 1; j < numHoverLocations; ++j)//
		{
			if (minHops[i][j] > numUAVs - 1) continue; //网格间距小于k-1则继续

			loop_time++;

			numDeployedLocations = 0;
			for (k = 0; k < numHoverLocations; ++k)	isToDeployUAV[k] = false;//152个位置初始化为false

			if (1 == minHops[i][j]){//如果选择的两点之间为1跳，则将该两点添加到集合中，并开始增长树
				numDeployedLocations = 2;//已部署位置2个
				hoverLocations[0] = i;
				hoverLocations[1] = j;
				isToDeployUAV[i] = isToDeployUAV[j] = true;
			}else
				findShortestPath(i, j);
			curThroughput = extendByGreedy(false, curSumDis);

			if (maxThroughput < curThroughput)
			{
				maxThroughput = curThroughput;
				bestSumDis = curSumDis;
			}
				

			if (loop_time % 1000 == 0)
				printf("%d th loop (percent %.2lf ), curThroughput : %.0lf, maxThroughput: %.0lf\n", loop_time, 200.0 * loop_time/(numHoverLocations*(numHoverLocations - 1)), curThroughput, maxThroughput);
		}
	}
	return maxThroughput;
}

double maxUAVCoverage::deepGreedyAlg(double & bestSumDis)
{
	int i, j;
	double maxThroughput = -1;
	double curThroughput;
	
	double curSumDis;
	for (i = 0; i < numHoverLocations; ++i)
	{
		numDeployedLocations = 1;
		hoverLocations[0] = i;
		for (j = 0; j < numHoverLocations; ++j)	isToDeployUAV[j] = false;
		isToDeployUAV[i] = true;
		
		
		curThroughput = extendByGreedy(false, curSumDis);
		if (maxThroughput < curThroughput) {
			maxThroughput = curThroughput;
			bestSumDis = curSumDis;
		}
		//if (i % 100 == 0 && i > 0) printf("%d th loop\n", i + 1);
	}
	return maxThroughput;
}

double maxUAVCoverage::motionControlAlg(double& bestSumDis)
{
	int i, j, k;

	double profit;
	double dis;
	// first assign the profit of each hovering locations as the number of users it covers
	for (i = 0; i < numHoverLocations; ++i) 
	{
		profit = 0;
		for (j = 0; j < numClusters; ++j)
		{
			dis = distance2D(xHoverLoc[i], yHoverLoc[i], xCluster[j], yCluster[j]);
			if (dis <= userCommRadius) // within communication range
				profit += numUsersPerCluster[j]; // 将在通信范围内的用户群都算在该hoverlocation覆盖用户里面
		}
		profitEachLocation[i] = profit;  
		if( verbose )
			printf("location %d, covered users: %lf\n", i, profit);
	}

	bool isLabelled[numHoverLocations];
	for (i = 0; i < numHoverLocations; ++i) isLabelled[i] = false;

	bool isCovered[numClusters];
	for (i = 0; i < numClusters; ++i) isCovered[i] = false;

	/*int sumCovered = 0;
	int bestIncreaseCovered;
	int bestNextLoc;
	int curCovered;
	
	// assign profit for each hovering location
	for (i = 0; i < numHoverLocations; ++i)  // increase the profit of each location by the greedy maximum coverage approach
	{
		bestIncreaseCovered = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isLabelled[j]) continue;

			curCovered = 0;
			for (k = 0; k < numClusters; ++k)
			{
				if (true == isCovered[k]) continue;
				dis = distance(xHoverLoc[j], yHoverLoc[j], xCluster[k], yCluster[k]);
				if (dis <= userCommRadius)
					curCovered += numUsersPerCluster[k];
			}

			if (curCovered > bestIncreaseCovered)
			{
				bestIncreaseCovered = curCovered;
				bestNextLoc = j;
			}
		}
		isLabelled[bestNextLoc] = true;
		profitEachLocation[bestNextLoc] = bestIncreaseCovered;
		for (k = 0; k < numClusters; ++k)
		{
			if (true == isCovered[k]) continue;
			dis = distance(xHoverLoc[bestNextLoc], yHoverLoc[bestNextLoc], xCluster[k], yCluster[k]);
			if (dis <= userCommRadius)	isCovered[k] = true; // this is covered now
		}
		
		sumCovered += bestIncreaseCovered;
		printf("%d th node, assign profit to node %d, profit: %d, total profit: %d\n", i + 1, bestNextLoc, bestIncreaseCovered, profitEachLocation[bestNextLoc]);
	}*/
	// the operation of assigning profit finishes
	// the hovering locations that cover many users are assigned higher profits

	int maxThroughput = 0;
	int curThroughput;
	for (i = 0; i < numHoverLocations; ++i)
	{
		numDeployedLocations = 1;
		hoverLocations[0] = i;
		for (j = 0; j < numHoverLocations; ++j)	isToDeployUAV[j] = false;
		isToDeployUAV[i] = true;

		extendByGreedyProfitLabel();
		curThroughput = calMaxThroughput();
		if (maxThroughput < curThroughput) {
			maxThroughput = curThroughput;
			bestSumDis = 0;
			int index;
			for (j = 0; j < numDeployedLocations; ++j)
			{
				index = hoverLocations[j];
				bestSumDis += distance3D(L / 2.0, W / 2.0, 0, xHoverLoc[index], yHoverLoc[index], h);
			}
		}
		//if (i % 100 == 0 && i > 0) printf("%d th loop\n", i + 1);
	}
	return maxThroughput;
}

double maxUAVCoverage::greedyProfitLabelAlg(double& bestSumDis)
{
	int i, j;
	bool isLabelled[numHoverLocations];
	for (i = 0; i < numHoverLocations; ++i) isLabelled[i] = false;
	for (i = 0; i < numHoverLocations; ++i) profitEachLocation[i] = 0;

	double sumThroughput = 0;
	double curThroughput;
	double bestIncreaseThroughput;
	int bestNextLoc;
	
	// assign profit for each hovering location
	int firstNode;
	numDeployedLocations = 0;
	for (i = 0; i < numHoverLocations; ++i)
	{
		bestIncreaseThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isLabelled[j]) continue;
			hoverLocations[numDeployedLocations] = j;
			numDeployedLocations++;
			curThroughput = calMaxThroughput();
			--numDeployedLocations;
			if (curThroughput - sumThroughput > bestIncreaseThroughput)
			{
				bestIncreaseThroughput = curThroughput - sumThroughput;
				bestNextLoc = j;
			}
		}
		isLabelled[bestNextLoc] = true;
		profitEachLocation[bestNextLoc] = bestIncreaseThroughput;
		if (0 == i) firstNode = bestNextLoc;

		sumThroughput += bestIncreaseThroughput;
		hoverLocations[numDeployedLocations] = bestNextLoc;
		numDeployedLocations++;
		if (bestIncreaseThroughput == 0) break;
		//printf("%d th node, assign profit to node %d, profit: %d\n", i + 1, bestNextLoc, bestIncreaseFlow);
	}
	// the operation of assigning profit finishes
	double maxThroughput = 0;

	numDeployedLocations = 1;
	hoverLocations[0] = firstNode;
	for (j = 0; j < numHoverLocations; ++j)	isToDeployUAV[j] = false;
	isToDeployUAV[firstNode] = true;
	extendByGreedyProfitLabel();
	maxThroughput = calMaxThroughput();
	bestSumDis = 0;
	int index;
	for (j = 0; j < numDeployedLocations; ++j)
	{
		index = hoverLocations[j];
		bestSumDis += distance3D(L / 2.0, W / 2.0, 0, xHoverLoc[index], yHoverLoc[index], h);
	}
	
	return maxThroughput;
}

double maxUAVCoverage::greedyAlg(double& bestSumDis)
{
	int i, j;
	int firstNode;
	int maxThroughput = -1;
	int curThroughput;
	numDeployedLocations = 1;
	for (j = 0; j < numHoverLocations; ++j)	isToDeployUAV[j] = false;
	for (i = 0; i < numHoverLocations; ++i)
	{
		hoverLocations[0] = i;
		curThroughput = calMaxThroughput();
		if (curThroughput > maxThroughput)
		{
			maxThroughput = curThroughput;
			firstNode = i;
		}
	}
	hoverLocations[0] = firstNode;
	isToDeployUAV[firstNode] = true;
	return extendByGreedy(false, bestSumDis);
}

double maxUAVCoverage::extendByGreedyProfitLabel()
{
	int i, j;
	int u, v;
	double totalThroughput;

	int minDis;
	for (i = 0; i < numHoverLocations; ++i)
	{
		if (true == isToDeployUAV[i]) continue;
		minDis = 1000000;
		for (j = 0; j < numDeployedLocations; ++j)
			if (true == adjMatrix[i][hoverLocations[j]])
				minDis = 1;
		nearestEdgeWeight[i] = minDis;
	}
	totalThroughput = 0;
	for (i = 0; i < numDeployedLocations; ++i)
		totalThroughput += profitEachLocation[hoverLocations[i]];

	double curIncreasedThroughput;
	double bestIncreasedThroughput;
	int bestNextLocation;
	while (numDeployedLocations < numUAVs)
	{
		bestIncreasedThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isToDeployUAV[j]) continue;
			if (nearestEdgeWeight[j] >= 2) continue; // not adjacent

			hoverLocations[numDeployedLocations] = j;
			numDeployedLocations++;

			curIncreasedThroughput = profitEachLocation[j];
			if (curIncreasedThroughput > bestIncreasedThroughput)
			{
				bestIncreasedThroughput = curIncreasedThroughput;
				bestNextLocation = j;
			}

			--numDeployedLocations;
		}
		if (-1 == bestIncreasedThroughput) break;

		hoverLocations[numDeployedLocations] = bestNextLocation;
		numDeployedLocations++;
		totalThroughput += bestIncreasedThroughput;

		isToDeployUAV[bestNextLocation] = true;
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (true == isToDeployUAV[j]) continue;
			if (true == adjMatrix[bestNextLocation][j])
				nearestEdgeWeight[j] = 1;
		}
	}
	return totalThroughput;
}

double maxUAVCoverage::extendByGreedy(bool vb, double& sumDis)//树增长算法，基于贪心算法
{
	int i, j;
	int u, v;
	double totalThroughput;

	int minDis;
	for (i = 0; i < numHoverLocations; ++i)
	//更新初始节点与其他网格之间的最短跳数nearestEdgeWeight
	{
		if (true == isToDeployUAV[i]) continue;
		minDis = 1000000;
		for (j = 0; j < numDeployedLocations; ++j)
			if (true == adjMatrix[i][hoverLocations[j]]) //adjMatrix在findMinHops中更新
				minDis = 1;
		nearestEdgeWeight[i] = minDis;
		//对于i网格，至少有1个节点是adjacent，则nearest为1
		//如果所有节点均不与其相邻，则为1000000
	}
	totalThroughput = calMaxThroughput();

	double newThroughput;
	int bestNextLocation;
	double bestIncreasedThroughput;
	while (numDeployedLocations < numUAVs)
	{
		bestIncreasedThroughput = -1;
		for (j = 0; j < numHoverLocations; ++j)
		//已有numDeployedLocations个点，现挨个增加，看哪个节点增加之后，吞吐增长是最大的
		{
			if (true == isToDeployUAV[j]) continue;
			if (nearestEdgeWeight[j] >= 2) continue; // not adjacent
			// 保证增加的节点都是联通的？？

			hoverLocations[numDeployedLocations] = j;
			numDeployedLocations++;

			newThroughput = calMaxThroughput();
			if (newThroughput - totalThroughput > bestIncreasedThroughput)
			//新增加后吞吐-已有节点吞吐，比现有最优增益大
			{
				bestIncreasedThroughput = newThroughput - totalThroughput;
				bestNextLocation = j;
			}

			--numDeployedLocations;
		}
		

		if (bestIncreasedThroughput == 0) break;

		hoverLocations[numDeployedLocations] = bestNextLocation;
		numDeployedLocations++;
		totalThroughput += bestIncreasedThroughput;

		isToDeployUAV[bestNextLocation] = true;
		
		for (j = 0; j < numHoverLocations; ++j)
		// 新增一个节点后，更新所有未部署网格与该bestnext节点跳数
		// 本质上是更新，新增的节点是否联通了某些未部署网格，若联通了，即1跳范围内，则更新为1
		{
			if (true == isToDeployUAV[j]) continue;
			if (true == adjMatrix[bestNextLocation][j])
				nearestEdgeWeight[j] = 1;
		}
	}

	sumDis = 0;
	int index;
	double dis;
	for (j = 0; j < numDeployedLocations; ++j)
	{
		index = hoverLocations[j];
		dis = distance3D(L / 2.0, W / 2.0, 0, xHoverLoc[index], yHoverLoc[index], h);
		sumDis += dis;
		if (vb) printf("location %d, (x, y, h): (%.0lf, %.0lf, %.0lf), dis: %.0lf\n ", j+1, 
			xHoverLoc[index], yHoverLoc[index], double(h), dis);
	}
	if (vb) printf("sum of distance: %.0lf\n", sumDis);

	return totalThroughput;
}

void maxUAVCoverage::findShortestPath(int s, int t)//节点s与节点t之间的最短路径，最终存储父子节点关系
{
	int sz = numHoverLocations;//常数152
	int i, j;

	for (i = 0; i < sz; ++i) visited[i] = false;
	for (i = 0; i < sz; ++i) parentSPT[i] = -1;
	//初始化两个数组
	visited[s] = true;
	queue_clear();
	queue_push(s);//节点s入队

	int u;
	while (queue_size() >0)//队列不为空时，进行以下操作
	{
		u = queue_pop();
		for (j = 0; j < numHoverLocations; ++j)
		{
			if (false == adjMatrix[u][j]) continue;
			//不跳出此次循环，则adjMatrix为true
			//true表示第j元素与u在一跳范围内
			if (true == visited[j]) continue;

			queue_push(j);
			visited[j] = true;//访问过则设置为true
			parentSPT[j] = u;
			//相邻则将u设置为j的父节点
			//因此所有与u相邻的节点的父节点均记为u
			//离该最短路径比较远的点的parentSPT未更新，值还是-1
		}
	}
	
	//assert(-1 != parentSPT[t]);// 如果为真，继续执行
	hoverLocations[numDeployedLocations] = t;
	numDeployedLocations++;
	isToDeployUAV[t] = true;
	//对第t个位置进行部署，并设置为true
	
	int v = t;
	while (-1 != parentSPT[v])
	{
		u = parentSPT[v];//将矩阵中第v节点所记录的其父节点赋值给u，此时u为v的父节点
		hoverLocations[numDeployedLocations] = u;//最新可部署位置设置为u
		numDeployedLocations++;//计数器增加
		isToDeployUAV[u] = true;//将u位置设置为可部署
		v = u;
	}
}

void maxUAVCoverage::initialization()//初始化，最开始需要计算的内容
{
	assignUserLocations();
	assignHoverLocatoins();
	findMinHopsAmongLocations();
	calAvgDataRates();
}

void maxUAVCoverage::findMinHopsAmongLocations()//最短跳
{
	
	bool visited[numHoverLocations];
	int minDis[numHoverLocations];
	int i, j;

	// 这两层循环不知道干嘛的。。
	// 现在知道了哈哈哈哈哈哈
	for (i = 0; i < numClusters; ++i)//40
		for (j = 0; j < numHoverLocations; ++j)//152
			disMatrix[i][j] = distance2D(xCluster[i], yCluster[i], xHoverLoc[j], yHoverLoc[j]);
			//第i个点分别与第j个点（152个）之间的2D距离
	
	//主循环，求得每个i点到其他个点的最短跳数
	for (i = 0; i < numHoverLocations; ++i)//152个网格，对于每个网格进行循环
	{	
		queue_clear();
		queue_push(i); // mininum hops from node i to other nodes, by applying BFS
		for (j = 0; j < numHoverLocations; ++j) visited[j] = false;//初始化为未访问
		visited[i] = true;
		for (j = 0; j < numHoverLocations; ++j) minDis[j] = 99999;//初始化为极大值
		minDis[i] = 0;

		int v;
		while (queue_size() > 0)
		{
			v = queue_pop();
			for (j = 0; j < numHoverLocations; ++j)
			{
				if (true == visited[j]) continue;//没被访问过
				if (distance2D(xHoverLoc[v], yHoverLoc[v], xHoverLoc[j], yHoverLoc[j]) <= R)
				//距离小于R时
				//R代表一跳距离，该距离内可能包括多个网格
				//该实验中，R=600，即600米内的网格都算1跳
				{
					minDis[j] = minDis[v] + 1;
					visited[j] = true;
					queue_push(j);
				}
			}

		}//while循环结束，所有点均被遍历一次
		//该过程求出了第i节点离其他所有节点最短跳，并将其存入下述minHops二维矩阵中
		//以下循环在主循环里
		for (j = 0; j < numHoverLocations; ++j)
			minHops[i][j] = minDis[j];
			//依次更新minHops[1][j]、minHops[2][j]、minHops[3][j]、……、minHops[i][j]
			//对于二维数组来说相当于一行一行更新，主循环每循环一次，更新一行
		/*if (verbose)
		{
			printf("minimum hops from node %d, to other nodes:----\n", i);
			for (j = 0; j < numHoverLocations; ++j)
				printf("(->%d, %d)\t", j, minHops[i][j]);
			printf("\n");
		}*/
	}

	for (i = 0; i < numHoverLocations; ++i)
		for (j = 0; j < numHoverLocations; ++j)
			adjMatrix[i][j] = false;//初始化矩阵为false
	for (i = 0; i < numHoverLocations; ++i)
		for (j = i + 1; j < numHoverLocations; ++j)
			if (distance2D(xHoverLoc[i], yHoverLoc[i], xHoverLoc[j], yHoverLoc[j]) <= R)
			//两点距离小于R，则认为该两点相邻，与网格相邻无关
			//即，不以网格相邻为标准进行判断，而是以一跳距离为标准，衡量是否相邻
				adjMatrix[i][j] = adjMatrix[j][i] = true;
}

void maxUAVCoverage::assignUserLocations()//用户群坐标分配及每群用户数量
{
	double con = (double)numUsers / (log2(numClusters) / log2(2.35));
	int i;
	int sumUsers = 0, curUsers;
	for (i = 1; i < numClusters; ++i)
	{
		curUsers = (int)ceil(con / i); // zipf distribution
		if (sumUsers + curUsers > numUsers)
			curUsers = numUsers - sumUsers;
		numUsersPerCluster[i - 1] = curUsers;
		sumUsers += curUsers;

	}
	numUsersPerCluster[numClusters - 1] = numUsers - sumUsers;

	xCluster[0] = 0; yCluster[0] = 0;
	xCluster[1] = L; yCluster[1] = W;
	xCluster[2] = 0; yCluster[2] = W;
	xCluster[3] = L; yCluster[3] = 0;
	for (i = 4; i < numClusters; ++i)
	{
		xCluster[i] = L * Uniform();
		yCluster[i] = W * Uniform();
	}

	if (verbose)
	{
		for (i = 0; i < numClusters; ++i)
			printf("cluster %d, users: %d, x: %.0lf,\ty: %.lf\n", i, numUsersPerCluster[i], xCluster[i], yCluster[i]);
	}
}

void maxUAVCoverage::assignHoverLocatoins()//悬停点坐标分配
{
	int rows = L / delta;
	int cols = W / delta;
	int i, j;
	int index = 0;
	for (i = 0; i < rows; ++i)//10行，10列，index为0-99，即100个格子
		for (j = 0; j < cols; ++j)
		{
			xHoverLoc[index] = delta / 2 + i*delta;
			//横坐标，每个网格以中间点表示，因此第一个位置为150，间隔300
			yHoverLoc[index] = delta / 2 + j*delta;//纵坐标
			index++;
		}
	for (i = 0; i < numClusters; ++i, ++index)//index再增加40
	{
		xHoverLoc[index] = xCluster[i];
		yHoverLoc[index] = yCluster[i];
	}

	double x, y;
	for (i = 0; i < 3; ++i, index += 4)
	{
		//consider the 3 clusters with the most people
		x = xCluster[i] - 100; // the left nearby location
		if (x < 0) x = 0;
		y = yCluster[i];
		xHoverLoc[index] = x;
		yHoverLoc[index] = y;

		x = xCluster[i] + 100; // the right nearby location
		if (x > L) x = L;
		y = yCluster[i];
		xHoverLoc[index + 1] = x;
		yHoverLoc[index + 1] = y;

		x = xCluster[i];
		y = yCluster[i] - 100; // the bottom nearby location
		if (y < 0) y = 0;
		xHoverLoc[index + 2] = x;
		yHoverLoc[index + 2] = y;

		x = xCluster[i];
		y = yCluster[i] + 100; // the top nearby location
		if (y > W) y = W;
		xHoverLoc[index + 3] = x;
		yHoverLoc[index + 3] = y;
	}

	if (verbose)
	{
		for (i = 0; i < numHoverLocations; ++i) 
			printf("location %d, x: %.lf\t, y: %.lf\n", i, xHoverLoc[i], yHoverLoc[i]);
	}
}
