#include<stdio.h>
#include<assert.h>
#include<math.h>
#include<time.h>
#include<iostream>
#include<fstream>
#include<ctime>
using namespace std;
#include "maxCoverageModified7.24final.h"

int main()
{
	
	/*if (verbose) // 输出assignUserLocations()结果
	{
		for (i = 0; i < numClusters; ++i)
			printf("cluster %d, users: %d, x: %.0lf,\ty: %.lf\n", i, numUsersPerCluster[i], xCluster[i], yCluster[i]);
	}
	
	if (verbose) // // 输出assignHoverLocatoins()结果
	{
		for (j = 0; j < numHoverLocations; ++j) 
			printf("location %d, x: %.lf\t, y: %.lf\n", j, xHoverLoc[j], yHoverLoc[j]);
	}	
	for (i = 0; i < numHoverLocations; ++i) 
	{
		printf("hover location %d covers %d clusters \n",i, numLocCoverClusters[i]);
		for (j = 0; j < numLocCoverClusters[i]; ++j)
		{
			printf("location %d covers the cluster %d\n",i, locCoverSpecCluster[j][i]);
		}
	}
	if (verbose) // 输出findMinHopsAmongLocations()结果
	{
		for (i = 0; i < numHoverLocations; ++i)
		{
			for (j = 0; j < numHoverLocations; ++j)
			{
				printf("locationX %d, locationY: %d, minHops: %d, adjMatrix: %s\n", i, j, minHops[i][j], adjMatrix[i][j] == true ? "true" : "false");
			}
		}
	}
	if (verbose)
	{
		for (i = 0; i < numHoverLocations; ++i) 
		{
			for (j = 0; j < numClusters; ++j)
			{
				printf("cluster %d is covered by location %d ? ----> %s because the distance is %.lf\n", j, i, isLocCoverUserMatrix[j][i] == true ? "true" : "false", disMatrix[j][i]);
			}
		}
	}

	
    int numUsersCoveredAppro = 0;
	double timeAppro = 0;
	st = clock();
	maxCoverage.initialization();
	//for (i = 0; i < numClusters; ++i) printf("cluster %d, users: %d, x: %.0lf,\ty: %.lf\n", i, numUsersPerCluster[i], xCluster[i], yCluster[i]);
	//for (j = 0; j < numHoverLocations; ++j) printf("location %d, x: %.lf\t, y: %.lf\n", j, xHoverLoc[j], yHoverLoc[j]);
	//numUsersCoveredAppro = maxCoverage.ApproAlgShort();
	//numUsersCoveredAppro = maxCoverage.AlgTreeDecomp();
	//numUsersCoveredAppro = maxCoverage.AlgAssign();
	numUsersCoveredAppro = maxCoverage.ApproAlgLong();
	ft = clock();
	timeAppro = static_cast<double>(ft - st) / CLOCKS_PER_SEC;
	printf("time is %lfs and users covered are %d\n", timeAppro, numUsersCoveredAppro);
	

	int numUsersCoveredKnapsack = 0;
	double timeKnapsack = 0;
	st = clock();
	maxCoverage.initialization();
	numUsersCoveredKnapsack = maxCoverage.AlgKnapsack();
	//numUsersCoveredKnapsack = maxCoverage.AlgKnapsackSlow();
	ft = clock();
	timeKnapsack = 1.0*(ft - st) / CLOCKS_PER_SEC;
	printf("time is %lfs and users covered are %d\n", timeKnapsack, numUsersCoveredKnapsack);
	
	int numUsersCoveredGreedy = 0;
	double timeCtrl = 0;
	st = clock();
	maxCoverage.initialization();
	numUsersCoveredGreedy = maxCoverage.AlgGreedy();
	ft = clock();
	timeCtrl = static_cast<double>(ft - st) / CLOCKS_PER_SEC;
	printf("time is %lfs and users covered are %d\n", timeCtrl, numUsersCoveredGreedy);*/



	int i, j, k, l, m, n;
	//srand(1);
	clock_t st, ft;
	maxUAVCoverage maxCoverage;

	int loop_times = 1;
	int loop;

	// ApproAlgShort
	double numUsersCoveredApproAlgShort = 0;
	double timeApproAlgShort = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredApproAlgShort += maxCoverage.ApproAlgShort();
	}
	ft = clock();
	numUsersCoveredApproAlgShort /= loop_times;
	timeApproAlgShort = (ft - st) / (1000.0 * loop_times);



	// ApproAlgLong
	double numUsersCoveredApproAlgLong = 0;
	double timeApproAlgLong = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredApproAlgLong += maxCoverage.ApproAlgLong();
	}
	ft = clock();
	numUsersCoveredApproAlgLong /= loop_times;
	timeApproAlgLong = (ft - st) / (1000.0 * loop_times);



	// AlgKnapsack
	double numUsersCoveredAlgKnapsack = 0;
	double timeAlgKnapsack = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredAlgKnapsack += maxCoverage.AlgKnapsack();
	}
	ft = clock();
	numUsersCoveredAlgKnapsack /= loop_times;
	timeAlgKnapsack = (ft - st) / (1000.0 * loop_times);


	// AlgTreeDecomp
	double numUsersCoveredAlgTreeDecomp = 0;
	double timeAlgTreeDecomp = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredAlgTreeDecomp += maxCoverage.AlgTreeDecomp();
	}
	ft = clock();
	numUsersCoveredAlgTreeDecomp /= loop_times;
	timeAlgTreeDecomp = (ft - st) / (1000.0 * loop_times);


	// AlgAssign
	double numUsersCoveredAlgAssign = 0;
	double timeAlgAssign = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredAlgAssign += maxCoverage.AlgAssign();
	}
	ft = clock();
	numUsersCoveredAlgAssign /= loop_times;
	timeAlgAssign = (ft - st) / (1000.0 * loop_times);


	// AlgGreedy
	double numUsersCoveredAlgGreedy = 0;
	double timeAlgGreedy = 0;
	st = clock();
	for (loop = 0; loop < loop_times; ++loop)
	{
		//printf("Appro Alg %d th loop...\n", loop + 1);
		srand(loop+100);
		maxCoverage.initialization();
		numUsersCoveredAlgGreedy += maxCoverage.AlgGreedy();
	}
	ft = clock();
	numUsersCoveredAlgGreedy /= loop_times;
	timeAlgGreedy = (ft - st) / (1000.0 * loop_times);


	printf("num of UAVs: \t%d\n", numUAVs);
	printf("num of Users: \t%d\n", numUsers);
	printf("users covered by Short Alg: \t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredApproAlgShort, timeApproAlgShort); 
	printf("users covered by Long Alg:\t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredApproAlgLong, timeApproAlgLong);
	printf("users covered by Knapsack Alg: \t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredAlgKnapsack, timeAlgKnapsack);
	printf("users covered by TreeDecomp Alg: \t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredAlgTreeDecomp, timeAlgTreeDecomp);
	printf("users covered by Assign Alg: \t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredAlgAssign, timeAlgAssign);
	printf("users covered by Greedy Alg: \t%.2lf Gpbs, time: %.2lf sec\n", numUsersCoveredAlgGreedy, timeAlgGreedy);
}
