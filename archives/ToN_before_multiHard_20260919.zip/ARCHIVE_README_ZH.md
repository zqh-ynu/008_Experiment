# ToN multi-hard 改造前源码与生成依据归档

归档日期：2026-09-19。来源提交：3b8b4ef2dac72a3ae34ed4cf0e9de656f0667e2c。
归档前 git 工作区干净；这是旧版快照，不是未提交补丁。

## 内容和边界

包含当前 C++ 算法及旧 EXP1--EXP5、Python 请求/部署生成器、4 个绘图入口、必要配置、原批次选中的30个县区空间样本。
不包含实验结果、最终用户/UAV实例、run_info、图片、程序二进制、第三方库或Git历史。
空间样本CSV是输入生成依据，不是实验结果。保持源码原貌，没有修复或重构。

## 原配置与依赖

Python 原批次：2026-09-07，30个实例，master_seed=20260904；逐实例种子与县区顺序见 generation_config_ToN.json。
配置记录 Python 3.12.14、NumPy 2.3.5、pandas 3.0.1；绘图还需 matplotlib。此处是原配置记录，不是本次重新执行验证。
C++ main：instance_count=10、master_seed=20260905、rounding_trials=2、ton_epsilon=0.1、output_name=run_ton_01；默认所有实验调用均被注释。
旧 EXP4 为带宽实验，旧 EXP5 为定位误差实验；本包没有采用新 multi-hard 实验定义。
使用 Visual Studio 2022/C++17，原工程含 Boost 1.89.0、IPOPT 3.14.19 win64 msvc2022 mdd、nlohmann.json 3.12.0 NuGet，以及 CPLEX/Concert 22.1.1 的本机链接配置。
恢复 NuGet 包；按工程配置准备库、include/lib路径及运行时DLL。Release|x64 当前使用与IPOPT mdd匹配的调试CRT/迭代器ABI，不要仅凭Release名称改变运行库。
这些外部依赖未打包，可能还依赖本机VS用户属性；本包不承诺解压即运行。

## 恢复步骤

1. 解压到新的工作目录，保持本包的相对路径，不覆盖原工程或旧结果。
2. 检查 predefine.h 中 algProjPath、experimentDataPath 和工程文件中的本机路径，按恢复位置调整。按项目配置安装依赖。
3. 重新生成时，读取保存的 generation_config_ToN.json，并按 replicates 中 replicate_id 的顺序使用 source_file。不可在仅有30个文件的目录上重新执行原 _select_source_files 随机选择逻辑。
4. 在恢复副本中将 generate_all_instances 的 selected_sources 改为上述记录顺序对应的文件列表；保持30个实例及原主种子，使 effective_seed 与记录一致。保留原生成循环中空间抽样、请求生成、比例生成的调用次序。生成配置已记录历史修复信息，供人工核对。
5. 选择不存在的新输出批次目录（原生成器拒绝已存在的批次），执行 instance_generator/generate_instances_ToN.py；生成用户请求和UAV部署可能耗时。不要在原归档中执行或覆盖保存的生成配置。
6. 将 C++ main.cpp 的 input_root 指向重建数据，output_name 选择新名字。实验物理配置来自 ExperimentsData/ExperimentsResults/EXP1--EXP4 对应目录的 def_config.json；EXP5复用EXP1配置。
7. 恢复副本编译后，在main中选择实验调用。生成结果后，调整保存的EXP1/2/3/5绘图脚本的输入路径并执行；绘图脚本可能校验旧批次的完成数量和算法版本，不能伪造元数据跳过校验。

## 原工程的过期引用

下列工程UI条目在归档时已经不存在；当前已收录源码的本地include不依赖它们。未补造，也未修改vcxproj。若恢复时IDE显示缺失，可在恢复副本中检查/移除过期条目：
- Algorithms/UAVBandwidthAllocation/test.h
- Algorithms/UAVBandwidthAllocation/test_route_a.h
- Algorithms/UAVBandwidthAllocation/route_a_batch.h
- Algorithms/UAVBandwidthAllocation/config/route_a_run_options.json
- Algorithms/UAVBandwidthAllocation/scripts/validate_route_a.ps1
- Algorithms/UAVBandwidthAllocation/scripts/run_route_a_batch.ps1
- Algorithms/UAVBandwidthAllocation/scripts/route_a_batch.py
- Algorithms/UAVBandwidthAllocation/scripts/plot_route_a.py
- Algorithms/UAVBandwidthAllocation/scripts/test_route_a_plot.py

## 复现限制

本包只保留源码与生成依据，未保存最终用户/UAV文件。旧批次有历史定向修复，重建数据不保证与旧输入逐字节一致，结果不保证与旧结果数值完全一致。
本次仅执行文件清单与ZIP可读性检查，没有编译、生成数据、运行实验、计算哈希或进行数值验证。

## 文件清单（不含本说明）

- Algorithms/UAVBandwidthAllocation/allocation_contract.h
- Algorithms/UAVBandwidthAllocation/config.h
- Algorithms/UAVBandwidthAllocation/config/def_config.json
- Algorithms/UAVBandwidthAllocation/config/readme.md
- Algorithms/UAVBandwidthAllocation/Convexrelaxationandrounding.cpp
- Algorithms/UAVBandwidthAllocation/EntityDefinition.cpp
- Algorithms/UAVBandwidthAllocation/EntityDefinition.h
- Algorithms/UAVBandwidthAllocation/experiment_support.h
- Algorithms/UAVBandwidthAllocation/experiments.h
- Algorithms/UAVBandwidthAllocation/HungarianMatching.cpp
- Algorithms/UAVBandwidthAllocation/LOCALIZATION_EXPERIMENT.md
- Algorithms/UAVBandwidthAllocation/localization_experiments.h
- Algorithms/UAVBandwidthAllocation/main.cpp
- Algorithms/UAVBandwidthAllocation/MatchGame_ipopt.opt
- Algorithms/UAVBandwidthAllocation/Matching_SQP_ipopt.opt
- Algorithms/UAVBandwidthAllocation/MatchingGameAllocation.cpp
- Algorithms/UAVBandwidthAllocation/MatchingSQP.cpp
- Algorithms/UAVBandwidthAllocation/packages.config
- Algorithms/UAVBandwidthAllocation/predefine.h
- Algorithms/UAVBandwidthAllocation/README.md
- Algorithms/UAVBandwidthAllocation/relax_rounding_ipopt.opt
- Algorithms/UAVBandwidthAllocation/SADA_algorithm.cpp
- Algorithms/UAVBandwidthAllocation/SADA_ipopt.opt
- Algorithms/UAVBandwidthAllocation/UAVBandwidthAllocation.sln
- Algorithms/UAVBandwidthAllocation/UAVBandwidthAllocation.vcxproj
- Algorithms/UAVBandwidthAllocation/UAVBandwidthAllocation.vcxproj.filters
- CHANGELOG.md
- ExperimentsData/data_ToN/2026-09-07/generation_config_ToN.json
- ExperimentsData/data_ToN/README.md
- ExperimentsData/DatasetTest/data/generated_user_loc/140405.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/140821.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/210211.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/230225.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/230229.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/350521.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/370832.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/371324.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/411202.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/420302.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/420324.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/420921.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/422827.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/430923.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/431227.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/433130.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/440983.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/451221.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/500238.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/510822.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/522624.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/530922.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/532928.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/540202.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/540424.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/540531.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/542523.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/610503.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/630104.csv
- ExperimentsData/DatasetTest/data/generated_user_loc/640122.csv
- ExperimentsData/DatasetTest/generate_user_data_ToN.py
- ExperimentsData/DatasetTest/instance_generator/generate_instances_ToN.py
- ExperimentsData/DatasetTest/README.md
- ExperimentsData/DatasetTest/uav_deployment.py
- ExperimentsData/ExperimentsResults/EXP1_user_num/def_config.json
- ExperimentsData/ExperimentsResults/EXP2_uav_num/def_config.json
- ExperimentsData/ExperimentsResults/EXP3_hard_user_ratio/def_config.json
- ExperimentsData/ExperimentsResults/EXP4_bandwidth/def_config.json
- ExperimentsData/ExperimentsResults/FigsDrawerProj/EXP1_Drawer.py
- ExperimentsData/ExperimentsResults/FigsDrawerProj/EXP2_Drawer.py
- ExperimentsData/ExperimentsResults/FigsDrawerProj/EXP3_Drawer.py
- ExperimentsData/ExperimentsResults/FigsDrawerProj/EXP5_Drawer.py
- README.md