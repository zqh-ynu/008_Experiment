#pragma once
#include "predefine.h"


//-------------------------------------------------------
// 1. ͨ�õ� Range �ṹ��
template <typename T>
struct Range {
    T min;
    T max;
};

// 2. ��ƽ���������ýṹ��
struct ExperimentConfig {
    // --- ������ (Topology) ---
    int num_uavs;
    int num_elastic_users;
    int num_hard_qos_users;
    Range<double> area_range; // �û��ֲ����� (min_coordinate ~ max_coordinate)

    // --- ҵ���� (Traffic & QoS) ---
    Range<double> rate_mbps_range; // ��С����Ҫ��Χ
    Range<int> outage_exp_range;   // �жϸ���ָ����Χ (10^-x)
    Range<int> weight_range;       // Ч��Ȩ�ط�Χ
};

ExperimentConfig load_experiment_config(const string& json_file_path) {
    ifstream ifs(json_file_path);
    if (!ifs.is_open()) {
        cerr << "Error: Cannot open config file: " << json_file_path << endl;
        exit(1);
    }

    json j;
    try {
        ifs >> j;
    }
    catch (json::parse_error& e) {
        cerr << "JSON Parse Error: " << e.what() << endl;
        exit(1);
    }

    ExperimentConfig cfg;

    // --- 1. ��ȡ�������� (�ֶ����Ƕ�׵� JSON) ---
    auto& topo = j["topology_settings"];
    cfg.num_uavs = topo["num_uavs"].get<int>();
    cfg.num_elastic_users = topo["user_counts"]["num_elastic_users"].get<int>();
    cfg.num_hard_qos_users = topo["user_counts"]["num_hard_qos_users"].get<int>();

    // ��ȡ����Χ
    cfg.area_range.min = topo["deployment_area"]["min_coordinate_m"].get<double>();
    cfg.area_range.max = topo["deployment_area"]["max_coordinate_m"].get<double>();

    // --- 2. ��ȡ�������� ---
    auto& traffic = j["traffic_generation_params"];
    auto& hard_qos = traffic["hard_qos_requirements"];

    // ��ȡ���ʷ�Χ
    cfg.rate_mbps_range.min = hard_qos["min_required_rate_range_mbps"]["min"].get<double>();
    cfg.rate_mbps_range.max = hard_qos["min_required_rate_range_mbps"]["max"].get<double>();

    // ��ȡ�жϸ���ָ����Χ (ע�� JSON key �� min_exponent)
    cfg.outage_exp_range.min = hard_qos["outage_probability_exponent_range"]["min_exponent"].get<int>();
    cfg.outage_exp_range.max = hard_qos["outage_probability_exponent_range"]["max_exponent"].get<int>();

    // ��ȡȨ�ط�Χ
    cfg.weight_range.min = traffic["utility_weight_range"]["min"].get<int>();
    cfg.weight_range.max = traffic["utility_weight_range"]["max"].get<int>();

    return cfg;
}



// ����������Ϣ�������ϵͳʵ��
SystemMd generate_instance(const ExperimentConfig& cfg) {
    std::mt19937 gen(42);

    // ֱ��ʹ�� cfg.area_range�������� cfg.topology.area...
    std::uniform_real_distribution<double> dist_pos(cfg.area_range.min, cfg.area_range.max);
    std::uniform_int_distribution<int> dist_weight(cfg.weight_range.min, cfg.weight_range.max);
    std::uniform_real_distribution<double> dist_rate(cfg.rate_mbps_range.min, cfg.rate_mbps_range.max);
    std::uniform_int_distribution<int> dist_pout_exp(cfg.outage_exp_range.min, cfg.outage_exp_range.max);

    vector<User> users;
    // ʹ�ñ�ƽ�������������
    int total_users = cfg.num_hard_qos_users + cfg.num_elastic_users;

    for (int i = 0; i < total_users; ++i) {
        // �ж�����
        int type = (i < cfg.num_hard_qos_users) ? HARD_UTILITY : ELASTIC_UTILITY;

        double x = dist_pos(gen);
        double y = dist_pos(gen);
        int weight = dist_weight(gen);
        double rMin = dist_rate(gen);
        double pOut = std::pow(10, -dist_pout_exp(gen));

        users.emplace_back(i, type, weight, x, y, 0.0, rMin, pOut);
    }

    // ����Uavʵ��
    vector<Uav> uavs;
    if (cfg.num_uavs == 1)
    {
        uavs.emplace_back(0, 0, 0, uav_alt, 20);
    }
    else if (cfg.num_uavs == 2)
    {
        uavs.emplace_back(0, 125, 0, uav_alt, 20);
        uavs.emplace_back(1, -125, 0, uav_alt, 20);
    }
    else
    {
        for (int i = 0; i < cfg.num_uavs; ++i) {
            // �򵥵ؽ� UAV ���ȷֲ���������
            double x = dist_pos(gen);
            double y = dist_pos(gen);
            uavs.emplace_back(i, x, y, uav_alt, 20); // ����ÿ�� UAV ����Ϊ 20 MHz
        }
    }

    return SystemMd(users, uavs);
}